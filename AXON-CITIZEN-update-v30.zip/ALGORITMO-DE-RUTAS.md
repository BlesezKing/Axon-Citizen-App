# Cómo elige AXON CITIZEN la ruta de misiones

Código: `src/Axon.Core/Routing/DestinationPlanner.cs` (el algoritmo), `TimeModel.cs` + `PlaceGeo.cs` (cuánto tarda una ruta: distancias reales), `TimeLearner.cs` + `RunRecorder.cs` (aprendizaje con tus tiempos), `RouteDb.cs`/`DistanceSync.cs` (SQLite y descarga de UEX) y `Contracts/MissionRank.cs` (rangos).
Con las mismas misiones, la misma nave y los mismos tiempos aprendidos sale siempre la misma ruta.

> **Novedad:** el modo por defecto es **Máx. aUEC/hora** (sección 9): maximiza `recompensa / tiempo` con distancias reales de UEX, el motor cuántico de tu nave y tus tiempos reales. Los demás modos siguen existiendo y ahora también muestran tiempo, aUEC/h, paradas y distancia. La estimación «por zonas» de la sección 6 solo se usa como respaldo cuando falta algún dato de distancia.

---

## 1. Las reglas que NUNCA se rompen (filtro previo)

Antes de comparar nada, una misión solo entra en el cálculo si cumple **todo** esto:

| Regla | Detalle |
|---|---|
| Está **pendiente** | Las ya aceptadas en el juego o terminadas no se recalculan; las aceptadas solo **ocupan cupo**. |
| Tiene **todas las cantidades leídas** | Si algún tramo tiene SCU = 0 (no se pudo leer), se excluye y se avisa para corregirla con ✎. |
| **Cabe en la nave**: SCU total ≤ capacidad | Una misión de 120 SCU no entra en un MOLE de 96. |
| **Cabe en cajas**: su caja máxima ≤ la caja máxima de la nave | Si la nave admite cajas de 4 SCU y la misión usa de 8, se excluye. |
| **Entrega en UN solo sitio** | Las misiones con entregas en varios destinos se descartan (la ruta tiene destino único). |
| Pasa el **filtro «Recoger en / Entregar en / Estoy en»** | La misión debe poder hacerse **entera** con los sitios marcados (todas sus recogidas y todas sus entregas dentro de lo marcado). |
| **Cupo de misiones**: máx. 10 aceptadas a la vez | `cupo = 10 − aceptadas`. La ruta nunca pasa de ese número. |

Resultado: las misiones elegibles se **agrupan por destino**. Cada destino se resuelve por separado y después se comparan.

---

## 2. Qué se calcula por cada destino

Para cada destino hay un problema de **mochila (0/1)**: de todas las misiones que entregan ahí, ¿cuáles me llevo?

* **Restricciones:** suma de SCU ≤ capacidad de la nave; nº de misiones ≤ cupo.
* **Qué se maximiza:** la suma del **valor** de cada misión (el valor cambia según el modo, ver sección 3).
* **Desempate** (en este orden): menos SCU → menos misiones → orden alfabético. Se implementa metiendo el desempate dentro del propio valor
  (`valor × 1.000.000 − SCU × 1.000 − 1`), así que la mochila ya devuelve la combinación más «ligera» entre las que empatan.
* Se resuelve con programación dinámica exacta: `dp[k][c]` = mejor valor con exactamente `k` misiones usando como mucho `c` SCU. No es una heurística: da el óptimo.

De cada destino salen **dos candidatos**:

1. **Mejor combinación** posible (valor máximo). Si hay empate de valor, se prefiere la que usa **menos sitios de recogida**: se prueban los conjuntos de recogidas de tamaño 1, 2, 3… y se queda con el primero que alcanza el valor máximo. Si hay más de 10 sitios de recogida no se prueban combinaciones (se usa la mochila global) y hay un **límite de 400 ms** de búsqueda; si se agota se avisa de que el resultado puede no ser el óptimo exacto.
2. **Mejor ruta «limpia»:** la mejor mochila usando solo misiones que se recogen **todas en un mismo sitio** (se prueba cada sitio y gana el que más valor da).

---

## 3. Qué cambia en cada modo

El modo solo cambia **(a) cuánto vale cada misión** y **(b) cuánto dinero se acepta ceder por una ruta limpia**.

| Modo | Valor de una misión | Tolerancia de ruta limpia |
|---|---|---|
| **Estándar** | su recompensa | 85 % |
| **Máx. dinero** | su recompensa | 100 % (nunca cede dinero) |
| **Eficiencia** | recompensa − coste de mover su carga | 85 % |
| **Máx. reputación** | rango primero, dinero después | solo entre las del mismo rango |

### 3.1 Máx. dinero
Valor = recompensa. Elige la combinación que más paga; con la tolerancia al 100 % la ruta limpia solo gana si paga **exactamente lo mismo** que la mejor. A igual dinero, la que lleva menos mercancía y menos recogidas.

### 3.2 Eficiencia (término medio)
Cada SCU transportado «cuesta» dinero:

```
precio_por_SCU_medio = (suma de recompensas de TODAS las misiones elegibles) / (suma de sus SCU)
coste_por_SCU        = precio_por_SCU_medio × 0,5          (EfficiencyFactor, configurable)
valor de la misión   = máx(1, recompensa − coste_por_SCU × SCU de la misión)
```

Una misión que paga bien **por SCU** vale más que otra que paga lo mismo pero obliga a mover el doble de carga. Una misión de 10 SCU que paga 60.000 (6.000/SCU) vale más que una de 40 SCU que paga 100.000 (2.500/SCU), aunque en bruto pague menos. El mínimo de 1 evita descartar una misión solo por llevar mucha carga. El factor 0,5 significa «mover un SCU cuesta la mitad de lo que de media se cobra por SCU»: es el punto intermedio entre ignorar la carga (máx. dinero) y penalizarla del todo.

### 3.3 Máx. reputación
La reputación real no se puede leer de la pantalla (el juego no la muestra por misión), así que se usa el **rango del contrato** como medida: cuanto más alto el rango del nombre de la misión, más reputación da.

```
Trainee (0) < Rookie (1) < Junior (2) < Member (3) < Experienced (4) < Senior (5) < Master (6)
```

* En cada destino **solo cuentan las misiones del rango más alto que haya en ese destino** (las demás se tiran).
* La puntuación del destino es `(rango + 2) × 1.000.000.000 + recompensa`: el rango **siempre** gana al dinero; el dinero solo desempata entre destinos de igual rango.
* Se acepta como ruta limpia únicamente si es del mismo rango máximo y paga al menos el 85 % de la mejor de ese rango.
* El rango se reconoce con tolerancia a erratas del OCR («Rokie Rank», «Membr Rank»…). Una misión sin rango reconocible vale −1.

### 3.4 Estándar
Es el modo clásico: valor = recompensa, con la regla de «ruta limpia» al 85 %.

---

## 4. Elegir la ruta recomendada entre destinos

Con los candidatos de todos los destinos:

1. Se **ordenan** por puntuación (descendente), y a igualdad: menos sitios de recogida → menos SCU → nombre del destino.
2. `topMoney` = el primero (el que más puntúa en el modo activo).
3. **Rutas limpias** = candidatos con **≤ 1 sitio de recogida** cuya puntuación sea **≥ tolerancia × la puntuación de topMoney**.
4. **Recomendada** = la primera ruta limpia si existe; si no, `topMoney`.

Es decir: *«si puedes recoger todo en un solo sitio y ganas casi lo mismo (85 %), te lo recomiendo aunque haya otra que pague algo más con varias recogidas»*. En Máx. dinero esa concesión desaparece (100 %).

La explicación que ves bajo la ruta añade, si procede, «hay una ruta con más recogidas que paga X aUEC más» o «el siguiente mejor destino pagaría Y».

---

## 5. Las otras opciones que muestra (para elegir tú)

* **Más aUEC:** el candidato con mayor recompensa bruta, si es distinto de la recomendada.
* **Más misiones / Menos misiones (más sencilla):** de otros destinos distintos de los ya destacados, el que más / menos misiones tiene.
* **Una opción por destino:** la mejor de cada destino (la limpia si vale ≥ tolerancia × la mejor, si no la mejor).
* **Alternativas:** hasta 3 candidatos más por puntuación, cada una con «paga X aUEC más/menos que la recomendada».

---

## 6. Orden de las paradas y tiempo estimado (modelo antiguo por zonas, ahora solo respaldo)

* **Estructura fija:** primero **todas las recogidas**, luego **la entrega única** (todas las entregas son en el mismo sitio).
* **Orden de recogidas** (`RouteGeo.OrderPickups`): minimiza el recorrido hasta el destino. Con ≤ 7 sitios prueba **todas las permutaciones**; con más, vecino más cercano. Si marcas «Estoy en X», el recorrido empieza en X.
* **«Distancia»** entre dos lugares (aproximación por zonas, no distancias reales):

| Relación | Minutos |
|---|---|
| Mismo sitio | 0 |
| Mismo planeta / zona | 6 |
| Mismo sistema, otro planeta | 14 |
| Otro sistema o desconocido | 30 |

* **Tiempo de la ruta** = 5 min por parada (aterrizar, ascensor, despegar) + los trayectos entre paradas según la tabla. Son valores orientativos, ajustables en `config.json` → `Estimate`.

---

## 7. Ejemplo corto

Nave de 96 SCU, 3 misiones que entregan en *Port Tressler*:

| Misión | Recompensa | SCU | Recogida |
|---|---|---|---|
| A | 60.000 | 10 | Everus Harbor |
| B | 100.000 | 40 | Everus Harbor |
| C | 70.000 | 30 | Baijini Point |

* **Máx. dinero:** A+B+C = 230.000 con 80 SCU y 2 recogidas. La ruta limpia (solo Everus: A+B = 160.000) vale el 70 % < 100 % → gana A+B+C.
* **Estándar:** igual cálculo pero tolerancia 85 %: 70 % < 85 % → también A+B+C.
* **Eficiencia:** precio medio = 230.000/80 = 2.875/SCU, coste = 1.437,5/SCU → valores A = 60.000−14.375 = 45.625; B = 100.000−57.500 = 42.500; C = 70.000−43.125 = 26.875. Cabe todo, pero si la nave fuese de 50 SCU elegiría A+C (72.500 de valor) en vez de B solo (42.500).
* **Máx. reputación:** si A es *Member* y B, C son *Rookie*, solo cuenta A (rango más alto), aunque pague menos.

---

## 9. Modo «Máx. aUEC/hora» (por defecto)

**Objetivo:** maximizar `recompensa total / tiempo total de la ruta`, respetando TODAS las reglas de la sección 1 (destino único, SCU, caja máxima, cupo de 10, filtros) y un **beneficio mínimo** por ruta (50.000 aUEC por defecto, `Time.MinProfit`).

### 9.1 Distancias reales
* Fuente: **UEX API 2.0 `orbits_distances`** (distancia quantum real entre órbitas, en Gm; ≈3.500 pares en Stanton, Pyro y Nyx) + `space_stations`, `cities`, `outposts` y `poi` para saber a qué órbita pertenece cada lugar. UEX no trae coordenadas; las distancias ya vienen medidas.
* Se guardan en SQLite (`rutas.db`: tablas `places`, `orbits`, `orbit_distance`). Botón **«Refrescar distancias»** en la pantalla «Tiempos»; además se descargan solas la primera vez y cada 14 días.
* Distancia entre dos lugares: misma órbita → `Time.SameOrbitGm` (0,03 Gm); mismo sistema → la de sus órbitas; **otro sistema** → hasta el gateway + salto (`Time.JumpS`) + desde el gateway de allí. Si falta el dato, aproximación por zonas (30 Gm mismo sistema, 60 otro).
* Los nombres que lee el OCR se convierten a lugar con el emparejamiento difuso de siempre; de los 400 lugares conocidos, 398 tienen órbita (los 2 restantes heredan la de su planeta).

### 9.2 Modelo de tiempo de una ruta (todo en `config.json` → `Time`)
`Tiempo = fijo por ruta + Σ por parada (aproximación + gestión + carga) + Σ viajes`

| Concepto | Valor inicial |
|---|---|
| Viaje quantum | `spool` + 4 s de calibración + aceleración + `distancia / velocidad` del **quantum drive de tu nave** (de «Naves» → Build → «Usar este motor cuántico»; la aceleración sale del tiempo de 10 Gm que da el juego para ese motor, o 45 s) × corrección aprendida |
| Salto entre sistemas | 120 s |
| Aproximación y aterrizaje | estación 120 s · ciudad 300 s · outpost en superficie 210 s |
| Despegue y salida | estación 60 s · ciudad 120 s · outpost 60 s |
| Ascensor de carga / hangar | estación 60 s · ciudad 90 s · outpost 45 s |
| Carga o descarga por caja | `6 s + 0,5 s × SCU de la caja` (caja de la misión, o 4 SCU si no consta) |
| Buscar y aceptar misiones | 300 s por ruta |

Número de cajas de un tramo = `⌈SCU / tamaño de caja⌉`; se descargan en el destino y se cargan en cada recogida.

### 9.3 Optimización (por destino)
1. Se enumeran los **subconjuntos de sitios de recogida** (hasta 14 sitios; los que dejan exactamente las mismas misiones elegibles se cuentan una vez, gana el más pequeño). Con más sitios se prueban sitios sueltos, parejas y el conjunto entero y se avisa.
2. Para un subconjunto, las misiones elegibles forman una **mochila** (SCU y cupo) donde cada misión vale `recompensa − λ · tiempo_de_carga(misión)`.
3. Para cada resultado se calcula el **orden óptimo de recogidas** (permutación exacta hasta 7 sitios; con más, vecino más cercano + 2-opt) y el tiempo total real de esa ruta.
4. **Dinkelbach** busca `max R/T`: se fija `λ` (empieza con la mejor ruta de dinero), se maximiza `R − λ·T` entre todos los subconjuntos y se actualiza `λ ← R*/T*`; cuando `λ` no mejora, es el óptimo (máx. 12 iteraciones).
5. Límite de tiempo de búsqueda 1,5 s repartido entre destinos; si se agota se devuelve lo mejor encontrado y se avisa de que puede no ser el óptimo exacto.
6. **Beneficio mínimo:** solo cuentan rutas con ≥ `MinProfit` aUEC; si ninguna llega, se muestra la de mejor aUEC/h con un aviso.
7. Entre destinos gana el de mejor aUEC/h con beneficio suficiente. La explicación compara con la ruta que más paga: *«La ruta a X paga 300.000 más pero tarda 1 h 30 min más: 250.000/h frente a 400.000/h»*.

Cada ruta y alternativa muestra: aUEC, tiempo, **aUEC/h**, paradas y distancia total (Gm).

### 9.4 Aprendizaje con tus tiempos
* Con una ruta activa, la tecla **F4** (`Hotkeys.Mark`) o el botón ⏱ del panel de ruta avanzan: **Salgo → Llegado a X → Carga terminada / Entregado** (por cada parada).
* `Llegado − salida anterior` = salida + viaje + aproximación. Si el trayecto es **largo** (≥ 5 Gm) se calibra la **velocidad real del quantum** (factor sobre lo teórico); si es **corto**, el **aterrizaje** de ese tipo de sitio y de ese sitio concreto.
* `Carga terminada − llegado` = ascensor + cajas. Con ≥ 4 cajas se calibran los **segundos por caja**; con menos, el **ascensor** del sitio y del tipo de sitio.
* **Media móvil exponencial** (`LearnAlpha` = 0,2): cada muestra pesa un 20 %, parte del valor inicial y se mueve poco a poco.
* **Valores absurdos descartados** (se anotan pero no cuentan): ≤ 0, más de 4× lo esperado (el café) o muy por debajo, o fuera de 3×MAD de tus últimas muestras de esa clave.
* Pantalla **«Tiempos»**: rutas con tiempo estimado frente al real (y aUEC/h real frente a estimado), todo lo aprendido con su valor inicial y nº de muestras, y botón para borrarlo.

---

## 8. Límites que conviene saber

* Es una ruta de **un solo viaje con un único destino** (a propósito: así es como se trabaja con estas misiones).
* La reputación se aproxima por el **rango del nombre**; no es la cifra real de reputación.
* Las distancias son las medidas por la comunidad (UEX) entre órbitas; dentro de una misma órbita (una luna y su planeta) se usa una distancia corta fija que se afina con tus tiempos. El tiempo es una estimación que mejora con cada ruta que midas.
* Los valores iniciales de aterrizaje, ascensor y carga son estimaciones, no medidas: hasta que marques unas cuantas rutas, el aUEC/h es orientativo.
* Si hay muchas misiones y muchos sitios de recogida, la búsqueda de «menos recogidas» se corta a los 400 ms y se avisa.
* Lo que se calcula depende de lo bien leído: una misión con SCU sin leer, o con destino mal leído, se excluye o se separa. Revisa los avisos ⚠.
