﻿# AXON CITIZEN — resumen completo de la aplicación

Documento pensado para dárselo a otra IA como contexto. Describe qué hace el programa, cómo está hecho, sus reglas y sus límites.

## 1. Qué es
Programa de escritorio para Windows (C# / .NET 8 / WPF) que acompaña a **Star Citizen** en el juego de **hauling** (misiones de transporte de carga). Muestra un overlay transparente encima del juego y una ventana principal normal.

**Restricción fundamental (riesgo de baneo):** es 100 % externo y pasivo.
- Solo captura píxeles de la pantalla (cuando el usuario lo pide o en modo escaneo) y los lee con el OCR de Windows.
- NO lee la memoria del juego, NO inyecta código, NO toca archivos del juego, NO pulsa teclas ni mueve el ratón dentro del juego, NO pide administrador.
- Lo único que dibuja es su propia ventana transparente.
- Red: solo descargas de datos públicos de UEX (uexcorp.space), y solo cuando el usuario pulsa el botón correspondiente.

Idioma de la interfaz: español. Los contratos del juego están en inglés.

## 2. Requisitos
- Windows 10 2004+ / Windows 11, .NET 8 Desktop Runtime, x64.
- Star Citizen en **ventana sin bordes** (en pantalla completa exclusiva ninguna ventana puede dibujarse encima).
- OCR de Windows: mejor con el paquete de idioma **inglés** (en-US). Si solo hay otro idioma, funciona peor; la app avisa y abre los ajustes de idioma.

## 3. Funciones principales

### 3.1 Lectura de contratos (captura + OCR)
- Lee el contrato abierto en el Contract Manager del mobiGlas: título, recompensa (aUEC), contratista, descripción, disponibilidad, tamaño máximo de caja y los **tramos de carga**: mercancía, SCU, sitio(s) de recogida y destino. Soporta contratos con varios cargamentos y varias recogidas por tramo.
- Reputación por misión: el campo existe, se guarda y se muestra (★) **solo si** el contrato la muestra en una línea con «Reputation»/«Rep» y una cifra. En las capturas vistas hasta ahora no aparece, así que normalmente queda vacío.
- Zonas de captura configurables (fracciones de la ventana del juego): título, recompensa, detalles, objetivos y columna de la lista (recompensa redondeada «76k» para cruzar datos).
- Preprocesado de imagen (umbral adaptativo/global, escalado ×1–3) y **consenso de varias variantes** de lectura con votación, arbitraje con la lista, reparación de confusiones de dígitos y rescate de lugares usando el texto de la descripción.
- Normalización difusa de lugares y mercancías contra la base de UEX (134 lugares incluyendo puertos espaciales extra, 175 mercancías). Ignora el ruido típico (por ejemplo el «. O» del círculo de la línea siguiente). Si un lugar es dudoso lo marca y sugiere «¿quisiste decir X?».
- Lugares que no están en la base se pueden confirmar («✓ Lugares OK») y se recuerdan; no se aprenden variantes mal leídas de sitios que ya existen.
- Lecturas dudosas se guardan solas (captura + texto OCR, las 15 últimas) en `debug-captures\dudosas\` para depurar.
- El overlay se excluye de la captura (`SetWindowDisplayAffinity` EXCLUDEFROMCAPTURE) para no leerse a sí mismo.

### 3.2 Validación y antiduplicados
- Avisos ⚠ por misión: recompensa o SCU sin leer, falta recogida o destino, lugar sin confirmar, recogidas que no suman el tramo, tramos idénticos, lectura poco fiable.
- Una misma misión leída varias veces (o con pequeños errores) es **un solo registro**: coincidencia difusa por recompensa, nombre, tramos (mercancía + SCU) y lugares. Misiones parecidas pero con otra recompensa/SCU/destino son registros distintos. Una relectura solo mejora campos; no resucita misiones completadas ni pisa correcciones manuales.
- Títulos y contratistas con una errata toman la grafía ya guardada si esa aparece en al menos dos misiones.

### 3.3 Modo escaneo
- Tecla F8 o botón. Vigila la zona del contrato; cuando el usuario cambia de misión y la pantalla se queda quieta (~400 ms, configurable), la lee sola.
- Al empezar: vacía la lista de pendientes, muestra el overlay y un aviso grande (toast) por cada misión detectada. Sonido distinto para misión nueva y para misión ya escaneada; sonido al terminar.
- Bajo coste: una sola zona reducida por sondeo (~8,6 ms de CPU por sondeo cada 200 ms) y cola de OCR en segundo plano.
- Al terminar (F8 otra vez) calcula las rutas.

### 3.4 Ciclo de vida de las misiones
- Estados: pendiente, aceptada (ruta activa), completada ✓, abandonada ⊘. Se pueden corregir (✎ editor completo) o borrar (✕).
- Máximo **10 misiones aceptadas** a la vez (ACCEPTED x/10): la ruta nunca pasa de ahí, contando las ya aceptadas.

### 3.5 Filtros de misiones escaneadas
- «Estoy en» (tu estación actual): usa solo misiones que se recogen ahí.
- «Recoger en» y «Entregar en»: listas de casillas con los sitios y cuántas misiones hay en cada uno (selección múltiple). Filtran la lista y las rutas.
- Para la lista basta con que coincida algún sitio; para planificar, la misión debe poder hacerse **entera** con los sitios marcados.

### 3.6 Planificador de rutas (un viaje, destino único)
Reglas, en este orden:
1. **Todas las entregas en el mismo sitio** (obligatorio).
2. Preferible recoger todo también en un solo sitio; si no, varias recogidas y luego todo al mismo destino.
3. No pasar de la capacidad (SCU) de la nave, de su caja máxima ni de 10 misiones.
4. Máxima recompensa.
5. A igualdad, menos sitios de recogida.

Funcionamiento:
- Agrupa las misiones por destino único y resuelve una mochila (knapsack por SCU con límite de número de misiones) por destino.
- Una ruta «limpia» (una sola recogida) se prefiere si paga al menos el 85 % de la que más paga (`SinglePickupTolerance`).
- **Tres modos de ruta (botones en el panel «Ruta»; se recuerda el último, `PlannerMode`):**
  - «Máx. dinero» (por defecto): siempre la combinación que más paga; a igualdad de dinero, la que menos mercancía y menos recogidas lleva.
  - «Eficiencia» (intermedio): valor de cada misión = recompensa − coste por SCU (0,5 × la media de aUEC por SCU de las misiones candidatas); buen dinero con poca carga.
  - «Máx. reputación»: solo las misiones del rango más alto (leído del nombre: Trainee < Rookie < Junior < Member < Experienced < Senior < Master) que compartan sitio de entrega; el destino con el rango más alto gana y, dentro de eso, máximo dinero y mínimas paradas.
- Ofrece **opciones para elegir**: Recomendada, Más misiones, Menos misiones (más sencilla) y, si procede, Más aUEC; además un desplegable «Otro destino» con todos los destinos posibles. «Aceptar esta ruta» marca esas misiones como ruta activa.
- Cada ruta incluye pasos ordenados: recogidas por zonas (mismo planeta seguido, terminando cerca del destino; si hay «Estoy en X», empieza ahí) y la entrega.
- Estimación orientativa de minutos y aUEC/hora (por zonas, no distancias reales; tiempos ajustables en `config.json` → `Estimate`).
- Notas de lugar del usuario (⚠) en los pasos.
- Se excluyen, explicándolo, misiones que no caben en la nave, con cajas demasiado grandes, con SCU sin leer o que entregan en varios sitios.
- **Checklist de la ruta activa:** ☐/☑ por paso, ▶ en el que toca; se marca con clic o con la tecla F6.
- Aviso cuando la carga llega al 90 % (configurable) o se pasa de la nave.

### 3.7 Jornadas (sesiones de trabajo)
- Iniciar/terminar (F7 o botón); se crea sola al completar la primera misión.
- Muestra aUEC ganados, misiones completadas/abandonadas, SCU transportados, tiempo, aUEC/hora, gastos (combustible, reparaciones…) y beneficio neto.
- Historial con detalle por jornada (misión, origen, destino, SCU, recompensa, reputación) y totales acumulados.
- **Estadísticas** con barras: aUEC por día, por contratista (total y media por misión), por ruta (aUEC/SCU) y mejores jornadas (aUEC/hora).
- **Exportar CSV** (jornadas y misiones; separador «;», con BOM para Excel) en Documentos\AxonCitizen.

### 3.7b Planificador por aUEC/hora y tiempos reales (10/2026)
- Modo por defecto **Máx. aUEC/h**: maximiza `recompensa / tiempo` por destino (subconjuntos de recogidas + mochila + orden óptimo de paradas + Dinkelbach), con beneficio mínimo (50.000) y todas las reglas de siempre. Ver `ALGORITMO-DE-RUTAS.md`.
- **Distancias reales**: UEX `orbits_distances` (Gm entre órbitas) + lugares con su órbita (`space_stations`, `cities`, `outposts`, `poi`), en SQLite `rutas.db` con botón «Refrescar distancias» (y descarga automática la 1.ª vez / cada 14 días). 398 de los 400 lugares del OCR tienen órbita.
- **Modelo de tiempo** (`config.json` → `Time`): quantum con el motor de la nave (velocidad, spool, tiempo de 10 Gm), saltos entre sistemas, aterrizaje/salida/ascensor por tipo de sitio, segundos por caja, tiempo fijo por ruta.
- **Aprendizaje**: tecla `F4` / botón ⏱ (Salgo → Llegado → Hecho/Entregado); media móvil exponencial (α 0,2) por tipo de sitio, sitio concreto, caja y velocidad del quantum; descarte de valores absurdos (4× lo esperado, 3×MAD). Pantalla **Tiempos**: estimado frente a real y lo aprendido.
- Límites: los tiempos iniciales son estimaciones (se corrigen con tus marcas); UEX no trae distancias dentro de una misma órbita (luna ↔ planeta): se usa 0,03 Gm y se afina aprendiendo.

### 3.7c Minería (10/2026)
- Pantalla **Minería** (equipo, bodega y refinado) y panel de overlay (F3; Ctrl+F3 calibra): ver README y docs/mining-research.md. Datos en Data/mining-*.json (parche 4.10.1 de la Wiki API, UEX, scminer.rocks) con tools/gen-mining-data.ps1.
- Lectura del HUD solo por captura + OCR (ajuste «Chroma» para texto de color sobre fondo gris). Limitaciones medidas con capturas reales: ver sección 10 del documento de investigación.
- Estimaciones declaradas: combinación de efectos, límite de rotura (scminer), «cuándo soltar». Sin verificar: fórmula de fractura, múltiplos del ping, efecto de la calidad en el precio, rendimiento/coste/tiempo reales del refinado.

### 3.8 Naves (módulo)
- Catálogo de ~340 naves y vehículos fusionando **UEX** (uexcorp.space/2.0: naves, precios de compra y alquiler, terminales) y la **Wiki de Star Citizen** (api.star-citizen.wiki: rol, tamaño, huecos con su pieza de serie, estadísticas y precios de piezas). Todo se guarda en SQLite local (`naves.db`): funciona sin conexión; la tabla de naves, piezas y precios se vuelve a descargar si cambia el esquema, y las builds guardadas y el registro de cambios se conservan siempre.
- Datos por nave: fabricante, tamaño, **roles** (varios), SCU de carga y de mineral, tripulación, caja máxima, precio de **compra** (aUEC y dónde) y **alquiler** (aUEC/día y dónde) con fecha y fuente, pledge en dólares (informativo), versión de los datos. Badges «Comprable», «Alquilable», «No disponible in-game», «Concepto».
- Filtros: rol, disponibilidad (todas / comprables / alquilables / ambas), fabricante, tamaño, rango de SCU y precio máximo de compra; buscador por nombre; ordenación por cualquier columna.
- **Ficha** con tres pestañas: Resumen, Dónde conseguirla (tablas ordenables de compra y alquiler) y Build.
- **Builds** (v. 10/2026, criterios de `Data/build-meta.json`, parche 4.10.1): de serie + propuestas **según el rol**, más las tuyas (guardar varias por nave, copiar como JSON, importar JSON). Cada hueco: pieza de serie, pieza elegida (cambiable), rendimiento relativo, precio y todas las tiendas con ubicación; coste total comparado con el de serie; desplegable «Fuentes y criterio» con los enlaces que respaldan la recomendación.
  - **Minería** (MOLE, Prospector…): tres propuestas — *Potencia* (Helix I/II; en naves con 2+ cabezales el último es un Lancet de apoyo; módulos Rieger-C3 + Focus III + Surge), *Estable* (Arbor/Lancet/Hofstede con Focus III + XTR-XL para minerales volátiles) y *Económica* (Hofstede + Focus II + Rieger-C2). Los **módulos** de cada cabezal son huecos propios (Helix I: 2, Helix II: 3…). Se expanden las torretas de minería del MOLE (3 cabezales). Es el **meta de la comunidad** (SC Miner, Space4Games, MMOPixel, datos del juego), expresado como listas de preferencia editables, no cifras escritas a mano.
  - **Salvamento** (Vulture, Reclaimer, Salvation): cabezal Baler (o el propio de la Salvation) con módulos Abrade + Cinch (*Equilibrada*) o Trawler + Abrade (*Rápida*); las piezas exclusivas de la Salvation (cabezal, Hart, Comer) solo se ofrecen a esa nave.
  - **Resto de roles** (combate, carga, exploración, sigilo…): la mejor pieza por **estadísticas reales** del juego según el rol (p. ej. combate prioriza velocidad y preparación del motor cuántico; carga y exploración, el menor consumo de combustible; sigilo, menos emisión EM) con una pequeña bonificación por clase (militar/competición en combate, sigilo en sigilo). No hay un «meta» fiable de estas piezas en fuentes públicas, así que aquí el criterio es automático.
  - Los criterios están en `Data/build-meta.json` (incluido en la app) y se pueden **sustituir** copiándolo a `%AppData%\AxonCitizen\data\build-meta.json`: si el meta cambia, se edita un texto, no el programa. Si una pieza de la lista ya no existe o no se vende, se pasa a la siguiente y, al final, a una elección por estadísticas.
  - Datos: se descartan las fichas duplicadas de la Wiki (dejando la que se compra y completando sus efectos con la completa); módulos con efectos con signo (ventana óptima, resistencia, inestabilidad, material inerte, potencia) leídos del texto del juego.
- Botones «Refrescar» (catálogo completo ≈20 MB), «Solo precios» (≈2 MB) y «Refrescar nave» (detalle, huecos, precios y piezas). Detecta y anota cambios («X ya no se puede alquilar en Y», cambios de precio en piezas de tus builds).
- «Usar en el planificador»: pone la capacidad (mayor entre carga y mineral) y la caja máxima en el optimizador de hauling.
- Límites: no hay API pública de «builds del meta»: el de minería y salvamento sale de guías de la comunidad (puede cambiar con cada parche) y el del resto de roles es un criterio automático por estadísticas; los consumibles de minería (Surge, Brandt…) se eligen según la roca, aquí solo se propone uno de base; la Wiki no da la arma/láser instalado de fábrica dentro de torretas y brazos, solo sus huecos; los precios son datos de la comunidad; no hace falta clave de API (si UEX la exigiera, se guarda en la configuración).
- Peticiones educadas: espaciadas (≥700 ms por servidor), con reintentos y respeto de «Retry-After»; solo se lanzan al pulsar un botón de refrescar.
- Catálogo antiguo (137 naves con carga y caja máxima, embebido) sigue como respaldo para la caja máxima.

### 3.9 Mercado y minerales (datos públicos de UEX)
- Ventana aparte. Descarga los precios solo al pulsar «Actualizar precios» y los guarda en caché.
- «Dónde vender» (terminales que te compran, del que más paga al que menos, con demanda en SCU), «Dónde comprar» (del más barato, con stock) y «Mejores rutas comerciales» para la capacidad de tu nave (limitadas por stock y demanda, solo precios de los últimos 30 días; beneficio = margen × SCU sin contar combustible ni tiempo).
- Atajo de minerales y gemas y buscador de mercancías con tolerancia a erratas. Muestra la antigüedad de cada dato. Son datos de la comunidad y pueden estar desfasados.

### 3.10 Datos y mantenimiento
- Botón para actualizar lugares, naves y mercancías desde UEX (se guardan en `data\`; si algo falla o está incompleto no se cambia nada). Se usan al reiniciar.
- Copias de seguridad automáticas (misiones, jornadas, config, lugares aprendidos, notas) al arrancar y al terminar una jornada, en `backups\` (las 20 últimas), y botón manual.
- Registro de errores en `logs\` (14 días) y mensajes en el overlay y en la ventana principal.

## 4. Interfaz

### 4.1 Overlay (ventana transparente siempre encima)
- Normalmente **click-through** (no capta el ratón ni el foco). En modo edición (F11) se pueden arrastrar y redimensionar paneles, mostrar/ocultar paneles, cambiar la opacidad y usar los botones ✓ ⊘ ✎ ✕ y «Aceptar ruta».
- **Elegir qué paneles se ven**: en la ventana principal («Herramientas y ajustes» → «Paneles del overlay») hay una casilla por panel; se guarda en la configuración. El «Modo compacto» deja solo el panel «Resumen».
- Paneles: Misiones de hauling, Ruta, Escaneo de misiones, Carga (barra de SCU), Jornada, Estado y Resumen (oculto de normal).
- Layout, opacidad y color guardados en la configuración; estilo HUD.

### 4.2 Ventana principal (normal, con barra de tareas)
Barra lateral de navegación con cinco secciones y una franja inferior con el último aviso y la nave activa:
- **Hauling / Planificador**: leer contrato, escanear, overlay, filtros (estoy en / recoger en / entregar en), misiones escaneadas y rutas con sus tres modos.
- **Jornadas**: jornada en curso con gastos; historial (tabla ordenable con buscador), detalle de la jornada, estadísticas con barras y exportar CSV.
- **Naves**: módulo descrito arriba.
- **Mercado**: dónde vender/comprar y rutas comerciales (tablas ordenables).
- **Ajustes**: aspecto (color de acento y tamaño de la interfaz automático o manual), overlay (opacidad, paneles visibles, modo compacto, restablecer), sonidos, datos y mantenimiento (CSV, copia de seguridad, carpeta de datos, notas de lugares, actualizar lugares y naves de UEX, aviso del idioma OCR), naves y precios (clave opcional de UEX), teclas globales, estado y diagnóstico, y registro.
Cerrarla cierra el programa. Se adapta a la resolución (1080p / 1440p / 4K) y, en ventanas estrechas, los paneles pasan de ir lado a lado a ir apilados.

### 4.4 Sistema de diseño
`src/Axon.App/Theme`: `Theme.xaml` (estilos base de controles y tablas), `Ds.cs` (tokens de color, espaciado y tipografía Bahnschrift; tarjetas biseladas, botones, insignias, pestañas, buscador, estados vacío / cargando / error, barras, animaciones), `Bevel.cs` (esquinas biseladas), `DataTable.cs` (tabla ordenable con filtro y estados), `SplitGrid.cs` (diseño adaptable). El overlay usa los mismos colores y esquinas biseladas.

### 4.3 Teclas globales (configurables en `config.json` o en la ventana)
| Tecla | Acción |
|---|---|
| F9 | Leer el contrato abierto |
| F8 | Iniciar/terminar escaneo |
| F7 | Iniciar/terminar jornada |
| F6 | Marcar el siguiente paso de la ruta |
| F10 | Mostrar/ocultar overlay |
| F11 | Modo edición |
| Ctrl+Alt+F12 | Salir |

Se registran por dos vías (RegisterHotKey + sondeo con GetAsyncKeyState) con antirrebote. Si el juego va como administrador o las F-teclas necesitan Fn, pueden no llegar: los botones lo cubren.

## 5. Arquitectura (modular)
- `src/Axon.Core` (sin interfaz, testeable): configuración y rutas (`AppConfig`, `ConfigStore`, `BackupService`), registro (`Log`), modelos y parser de contratos (`Models`, `ContractParser`, `ReadingConsensus`, `Resolvers`, `MissionStore`, `MissionFilter`, `MissionValidator`, `ShipCatalog`, `UserLocationStore`), coincidencia difusa (`FuzzyMatcher`), detección de cambios del escaneo (`ChangeDetector`), planificador (`DestinationPlanner`, `RoutePlan`, `RouteGeo`, `PlaceNotes`), jornadas (`WorkSession`, `SessionStore`, `SessionStats`), mercado (`MarketData`), datos de UEX (`UexData`, `DataFiles`) y naves (`Ships/`: `ShipDb` SQLite, `ShipSync`, `ApiClient`, `ShipParsers`, `RoleCatalog`, `BuildAdvisor`). Datos incluidos como recursos: `locations.json`, `cargo.json`, `ships.json`.
- `src/Axon.App` (WPF): `OverlayController` (parcial: base, captura/escaneo, misiones, extras), `AppState`, `OverlayWindow`, `WidgetHost`, `Widgets`, `MainWindow` (navegación) y `Pages/` (`HaulingPage`, `SessionsPage`, `ShipsPage`, `MarketPage`, `SettingsPage`), `Ships/` (`ShipsService`, `ShipBuildView`), `Theme/` (sistema de diseño), `MissionFilterPanel`, `MissionEditorWindow`; captura y OCR (`ScreenCapture`, `ImagePrep`, `WindowsOcr`, `ContractReader`, `MissionScanner`); interoperabilidad Win32 (`Native`, `HotkeyManager`, `GameWindow`).
- `tests/Axon.Tests`: 483 tests (parser, consenso OCR, lugares, almacén, antiduplicados, planificador y sus tres modos, filtros, jornadas, estadísticas, copias, mercado, datos UEX, y el módulo de naves: lectores de UEX y Wiki con respuestas reales, base de datos, sincronización con fallos de red, builds, importar/exportar). `tests/samples` + `tools/verify-samples.ps1`: 6 capturas reales de contratos leídas con el OCR real (todas coinciden). `tools/gen-data.ps1` regenera los datos.
- Se añaden nuevos tipos de misión con un parser nuevo, su modelo y un widget en `WidgetCatalog`; la captura y el OCR se reutilizan.

## 6. Archivos de datos (`%AppData%\AxonCitizen\`)
`config.json` (teclas, opacidad, zonas de captura, naves, escaneo, sonidos, estimación, aviso de carga, copia automática), `missions.json`, `sessions.json`, `user-locations.json`, `place-notes.json`, `market-cache.json`, `data\*.json` (actualizados desde UEX), `backups\`, `logs\`, `debug-captures\`.

## 7. Estado y límites conocidos
- Probado con 483 tests, capturas reales de contratos y simulaciones del escaneo. **No se ha probado de forma sistemática con teclas y clics reales dentro del juego.**
- La reputación por misión no se ha podido leer: se desconoce en qué pantalla aparece.
- El OCR de Windows solo tiene español instalado en el equipo del usuario; el inglés mejoraría mucho la lectura.
- La estimación de tiempo es aproximada y no hay estimación de combustible.
- No hay prioridad por contratista/reputación ni lectores para otros tipos de misión (minería, salvamento, recompensas): faltan capturas de esas pantallas.
- Los precios del mercado son colaborativos (UEX) y pueden estar desactualizados.
- Windows reconoce el OCR en es-ES; los contratos están en inglés.

## 8. Ideas pendientes
Prioridad por contratista o reputación, lectores de otros tipos de misión, estimación de combustible, notas de peligro precargadas (hoy las escribe el usuario).


