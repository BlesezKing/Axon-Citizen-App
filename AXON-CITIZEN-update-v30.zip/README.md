# AXON CITIZEN · Overlay de hauling

Compañero externo y pasivo para Star Citizen. Lee la pantalla (captura + OCR), muestra un HUD encima del juego y calcula
la mejor combinación de misiones de hauling para un solo viaje.

**Qué NO hace:** no lee la memoria del juego, no inyecta código, no toca archivos del juego, no pulsa teclas ni mueve el
ratón dentro del juego, no usa administrador. Solo copia píxeles de la pantalla cuando pulsas la tecla de captura y dibuja
su propia ventana transparente.

## Requisitos
- Windows 10 2004+ / Windows 11, .NET 8 Desktop Runtime.
- Star Citizen en **ventana sin bordes** (no en pantalla completa exclusiva: ahí ninguna ventana puede dibujarse encima).
- Un idioma de OCR de Windows. Mejor **inglés** (los contratos están en inglés); funciona también con otro idioma latino.

## Teclas (se cambian en `%AppData%\AxonCitizen\config.json`)
| Tecla | Acción |
|---|---|
| `F9` | Leer el contrato que tienes abierto en el Contract Manager |
| `F10` | Mostrar / ocultar el overlay |
| `F11` | Modo edición: mover/redimensionar paneles, corregir (✎) o borrar (✕) misiones, opacidad |
| `Ctrl+Alt+F12` | Salir |

## Interfaz rediseñada y módulo «Naves»
- **Ventana principal con navegación lateral**: Hauling / Planificador · Jornadas · Naves · Mercado · Ajustes. Estilo inspirado en el HUD de Star Citizen (fondo oscuro, acentos cian, líneas finas, esquinas biseladas, animaciones suaves). El color de acento y el tamaño de la interfaz (automático según 1080p / 1440p / 4K) se cambian en Ajustes.
- **Sistema de diseño central** (`src/Axon.App/Theme`): `Theme.xaml` (estilos de botones, casillas, desplegables, tablas…), `Ds.cs` (colores, espaciados, tarjetas, insignias, pestañas, estados vacío / cargando / error), `DataTable` (tablas ordenables por columna, con filtro) y `SplitGrid` (paneles que pasan a apilarse en ventanas estrechas). El overlay usa los mismos colores.
- **Naves**: catálogo de ~340 naves y vehículos con fabricante, tamaño, **roles** (varios por nave: minería, salvamento, hauling/carga, combate, exploración, transporte, refinado, médica…), SCU, tripulación, **dónde y por cuánto se compra o se alquila** (precio por día) y badges «Comprable», «Alquilable» y «No disponible in-game». Filtros por rol, disponibilidad, fabricante, tamaño, SCU y precio; buscador; orden por cualquier columna.
- **Ficha de nave**: resumen, todos los puntos de compra y alquiler con fecha y fuente, y **builds**: la de serie y propuestas **por rol** — en **minería** (MOLE, Prospector…): *Potencia*, *Estable* y *Económica* con los mejores **cabezales y módulos** según las guías de la comunidad; en **salvamento** (Vulture, Reclaimer, Salvation): *Equilibrada* y *Rápida* (cabezal + módulos rascadores); en el resto, la mejor pieza por estadísticas del juego para el rol, solo entre las que se compran; cada hueco muestra la pieza de serie, la elegida (editable), su rendimiento, su precio y **todas las tiendas donde se compra**; coste total. Puedes guardar varias builds por nave, copiarlas como JSON e importar las de otros.
- **«Usar en el planificador»** pone la capacidad (SCU) y la caja máxima de la nave en el optimizador de hauling.
- **Datos**: UEX (uexcorp.space) y la Wiki de Star Citizen (api.star-citizen.wiki), guardados en una base SQLite local (`%AppData%\AxonCitizen\naves.db`): sin conexión se usan los últimos datos. Botones «Refrescar» (todo, ≈20 MB), «Solo precios» (≈2 MB) y «Refrescar nave» (en la ficha); avisan de cambios («X ya no se puede alquilar en Y»). Ninguna API necesita clave hoy; si UEX la exigiera, se pone en Ajustes → Naves y precios.
- **Cómo se eligen las piezas**: cabezales y módulos de minería y salvamento siguen el *meta* de la comunidad (SC Miner, Space4Games, MMOPixel y los datos del juego), guardado como listas de preferencia en `Data/build-meta.json` con sus enlaces (desplegable «Fuentes y criterio» en la ficha). El resto (escudos, generadores, refrigeradores, motor cuántico, armas) se elige por **estadísticas reales** según el rol (combate: velocidad y preparación del motor; carga/exploración: consumo de combustible; sigilo: emisión EM…). Si cambia el meta, copia ese archivo a `%AppData%\AxonCitizen\data\build-meta.json` y edítalo: no hace falta actualizar la app. Siempre puedes cambiar cualquier pieza a mano.

## Tres modos de ruta
Tres botones arriba del panel «Ruta» (ventana principal o modo edición). Se recuerda el último:
- **💰 Máx. dinero** (por defecto): siempre la combinación que más paga en total (máximo 10 misiones, con la capacidad de tu nave). Si dos combinaciones pagan lo mismo, elige la que lleva menos mercancía y menos sitios de recogida. No cede dinero por tener menos paradas.
- **⚖ Eficiencia** (intermedio): buen dinero llevando poca carga. Cada misión vale su recompensa menos lo que cuesta mover su mercancía (la mitad de lo que pagan de media las misiones por SCU; `EfficiencyFactor`). Así prefiere misiones que pagan mucho por SCU, sin descartar las grandes si no hay otra cosa.
- **⭐ Máx. reputación**: solo las misiones del **rango más alto** que haya (se lee del nombre: Trainee < Rookie < Junior < Member < Experienced < Senior < Master), todas con el **mismo sitio de entrega**. Las de rango inferior no entran aunque paguen más. Gana el destino con el rango más alto; dentro de eso, el máximo dinero y las mínimas paradas. La ruta muestra el rango («2 Member»).

## Mejoras de la última versión
- **Avisos de lectura** (⚠ en ámbar bajo cada misión): SCU sin leer, recompensa sin leer, recogidas que no suman el tramo, tramos repetidos, lugares sin confirmar («¿quisiste decir X?»).
- **Lugares más robustos**: el «. O» que se cuela del círculo de la línea siguiente se ignora; «✓ Lugares OK» ya no aprende variantes mal leídas de sitios que existen; al arrancar se reparan las misiones guardadas. Títulos y contratistas con una errata del OCR toman la grafía que ya tienes guardada.
- **Checklist de la ruta activa**: ☐/☑ por paso con ▶ en el que toca. Se marca con clic (modo edición o ventana principal) o con la tecla **F6** («siguiente paso»; se cambia en `config.json` → `Hotkeys.NextStep`).
- **Orden de paradas por zonas** (mismo planeta seguido, terminando cerca del destino; si marcas «Estoy en X», empieza ahí) y **estimación de tiempo y aUEC/hora** (`≈ N min`, orientativa; los tiempos se ajustan en `config.json` → `Estimate`).
- **Notas de lugares**: botón «Notas de lugares» abre `place-notes.json` (`"Lugar": "nota"`); salen con ⚠ en el paso de la ruta. No traen notas inventadas: las pones tú.
- **Aviso de carga casi llena** (por defecto al 90 %, `CapacityWarnPercent`) y si te pasas de la nave.
- **Elegir qué paneles se ven**: en la ventana principal, «Herramientas y ajustes» → «Paneles del overlay» con una casilla por panel (misiones, ruta, escaneo, carga, jornada, estado, resumen). Se guarda. También sigue disponible en modo edición (F11).
- **Modo compacto**: un solo panel «Resumen» (siguiente paso, carga y jornada) en vez de todos.
- **Sonidos configurables** (misión nueva, ya escaneada, fin del escaneo, avisos).
- **Estadísticas** en el historial: aUEC por día, por contratista, por ruta y mejores jornadas (barras). **Exportar CSV** (Documentos\AxonCitizen, separador «;», se abre con Excel).
- **Copias de seguridad automáticas** al arrancar y al terminar una jornada (`backups\`, las 20 últimas) y botón manual.
- **Mercado y minerales**: dónde vender, dónde comprar y mejores rutas comerciales para tu nave con precios públicos de UEX (se descargan solo al pulsar «Actualizar precios»; son datos de la comunidad y pueden estar desfasados).
- **Actualizar lugares y naves** desde UEX con un botón (se guarda en `data\`; si algo falla se siguen usando los incluidos).
- **Idioma del OCR**: si no tienes el inglés instalado, la ventana principal te lo avisa y abre los ajustes de idioma de Windows.

## Elegir ruta y filtros
- **Modo «Máx. aUEC/h» (por defecto)**: elige la ruta que maximiza recompensa ÷ tiempo, con **distancias reales de UEX** entre órbitas (SQLite, botón «Refrescar distancias» en la pantalla **Tiempos**), el **motor cuántico de tu nave** (Naves → Build → «Usar este motor cuántico»), aterrizajes por tipo de sitio (estación / ciudad / outpost), ascensor de carga, tiempo por caja y 5 min fijos por ruta, con un **beneficio mínimo** de 50.000 aUEC por ruta. Todos los valores están en `config.json` → `Time`. **Aprende de ti**: con una ruta activa pulsa `F4` (o el botón ⏱) en «Salgo», «Llegado a X» y «Carga terminada / Entregado»; la app calibra con media móvil, descarta los valores absurdos y muestra estimado frente a real en **Tiempos**. Cada ruta enseña aUEC, tiempo, aUEC/h, paradas y distancia.
- **«Misiones a coger» (en el panel de ruta)**: cada misión de la ruta recomendada con lo que la distingue de las que se llaman igual — recompensa en miles (`50k`) y exacta, SCU, mercancía y tiempo restante — y, debajo, las **misiones iguales NO elegidas** (mismo nombre, recogida y destino) con cuánto menos pagan o cuánta carga más llevan. Desaparece al marcar `F4` (empiezas a cargar; si no habías aceptado la ruta, `F4` la acepta) y vuelve al escanear.
- **Minería** (pantalla «Minería» + panel del overlay): perfiles de equipo (nave con capacidad editable, láser y módulos por cabezal, gadget) con sus estadísticas combinadas y la estimación de si una roca se rompe; bodega con valor sin refinar y refinado y presupuestos de refinería (a mano o leyendo el terminal con 📷). El overlay (`F3`) lee el HUD por **captura de pantalla + OCR** (no toca la memoria ni los archivos del juego): bodega, indicador de carga con aviso de soltar, roca y ping; `Ctrl+F3` calibra las zonas. Datos del parche 4.10.x en `Data/mining-*.json` (regenerables con `tools/gen-mining-data.ps1`); lo no verificado está en `docs/mining-research.md`.
- **Opciones de ruta para elegir** (panel «Ruta», clic en una): *Recomendada*, *Más misiones*, *Menos misiones (más sencilla)* y, si la recomendada no es la que más paga, *Más aUEC*. Cada una entrega TODO en un único destino distinto. En la ventana principal hay además un desplegable «Otro destino» con todos. **Aceptar esta ruta** acepta la que hayas elegido.
- **Filtros de las misiones escaneadas** (ventana principal): «Estoy en» (tu estación: usa solo misiones que se recogen ahí), «Recoger en» y «Entregar en» (casillas con los sitios de las misiones y cuántas hay). Filtran la lista y las rutas; las rutas solo usan misiones que se hagan ENTERAS con los sitios marcados.
- **Máximo 10 misiones aceptadas**: la ruta nunca pasa de ahí, contando las que ya llevas.
- **Recogida en un solo sitio** preferida si paga ≥ 85 % de la ruta que más paga (`SinglePickupTolerance`).
- **Reputación**: se guarda por misión (y en el historial) si el contrato la muestra en una línea con «Reputation»/«Rep» y una cifra.
- Sonido distinto si escaneas una misión que ya tenías.

## Jornadas y modo escaneo
- **Completar misiones**: cada misión tiene ✓ (completada: suma su recompensa a la jornada) y ⊘ (abandonada/fallida: queda anotada pero no suma). Están en la ventana principal y, en el overlay, en modo edición (`F11`).
- **Jornada**: `F7` o botón «Iniciar / terminar jornada». Si no hay ninguna, se crea sola al completar la primera misión. El widget «Jornada» muestra aUEC ganados, misiones, SCU, tiempo y aUEC/hora; al terminar se guarda un resumen (fecha, duración, cada misión con origen, destino, SCU y recompensa, total y aUEC/hora). **Gastos** (combustible, reparaciones…) se restan para el beneficio neto. «Historial de jornadas…» lista todas con su detalle y el total acumulado. Se guarda en `%AppData%\AxonCitizen\sessions.json`.
- **Modo escaneo**: `F8` o botón. Minimiza AXON y pone el juego en primer plano; con cada contrato abierto pulsas `F9` y se captura **una sola foto**, que se lee en orden (el aviso y el sonido son de ESA misión). `F8` otra vez termina. Los lugares que no están en los datos pero que la descripción del mismo contrato nombra igual se aprenden solos (ya no piden «Lugares OK»). Opción `Scan.Auto: true` en `config.json` para volver a las capturas automáticas al detectar cambio de pantalla. Antiduplicados: la misma misión leída varias veces (o con pequeños errores del OCR) es un único registro; misiones parecidas pero con otra recompensa, SCU, destino o contratista son registros distintos. Al terminar (`F8` otra vez) calcula la mejor ruta.
- **Reglas de la ruta**: 1) todas las entregas en el MISMO sitio (obligatorio); 2) las recogidas pueden estar en sitios distintos; 3) sin pasar de los SCU de la nave ni de su caja máxima; 4) máxima recompensa; 5) a igualdad de recompensa, menos sitios de recogida. Por cada destino se resuelve una mochila; gana el destino que más paga y los siguientes son las alternativas. **Aceptar ruta** marca esas misiones como ruta activa para ir completándolas.
- Ajustes del escaneo en `config.json` → `Scan` (`PollMs`, `StablePolls`, `PixelDiff`, `ChangedPixels`).

## Novedades de versiones anteriores
- **Ventana principal** con botones para todo (leer contrato, overlay, edición), diagnóstico de teclas y registro. Cerrarla cierra el programa.
- **Catálogo de 137 naves y vehículos** con su capacidad y caja máxima, con buscador tolerante a erratas («cutlas black»).
- **Contratos con varios cargamentos**: cada «Deliver N/M SCU of …» es un tramo, aunque el OCR pierda la palabra «Deliver»; si hay más entregas en pantalla que las entendidas, avisa.
- **Lugares aprendidos**: lo que no está en la base de datos se marca con ⚠; «✓ Lugares OK» (o guardar con ✎) lo recuerda para las próximas lecturas (`user-locations.json`).
- **Lecturas dudosas guardadas solas** en `debug-captures\dudosas\` (captura + texto del OCR, las 15 últimas) para poder afinar el lector con casos reales.
- **Lectura automática (experimental)**: opcional; lee sola cuando la pantalla de contrato se queda quieta.
- Teclas por dos vías (Windows + sondeo) y contador de pulsaciones en el diagnóstico.

## Archivos
- `%AppData%\AxonCitizen\config.json` – teclas, opacidad, color, posiciones, perfiles de nave, zonas de captura.
- `%AppData%\AxonCitizen\missions.json` – misiones leídas.
- `%AppData%\AxonCitizen\logs\` – registro de errores (14 días).
- `%AppData%\AxonCitizen\debug-captures\` – recortes y texto del OCR de cada lectura si pones `"SaveDebugCaptures": true`.

## Estructura del código
| Proyecto | Contenido |
|---|---|
| `src/Axon.Core` | Sin interfaz y testeable: configuración, log, modelos, parser de contratos, coincidencia aproximada de lugares, almacén de misiones, optimizador de rutas. |
| `src/Axon.App` | WPF: overlay y widgets (`Overlay/`), teclas globales (`Interop/`), captura, preprocesado y OCR (`Capture/`). |
| `tests/Axon.Tests` | 65 tests (parser, lugares, almacén, optimizador, configuración). |
| `tests/samples` | Capturas reales de contratos + `expected.json`. `tools/verify-samples.ps1` las lee con el OCR real y compara. |
| `tools/gen-data.ps1` | Regenera `locations.json` y `cargo.json` desde los datos de UEX. |

Para añadir otros tipos de misión (minería, salvamento, bounty…): un parser nuevo en `Axon.Core/Contracts`, su modelo y un
widget nuevo en `WidgetCatalog`. La captura y el OCR se reutilizan.

## Comandos
```
dotnet build src/Axon.App -c Release
dotnet test tests/Axon.Tests
powershell -ExecutionPolicy Bypass -File tools\verify-samples.ps1
AxonCitizen.exe --ocr-test captura.png --out carpeta      (lee una imagen y vuelca el texto del OCR y el resultado)
AxonCitizen.exe --snapshot overlay.png --demo [--edit]     (dibuja el overlay a un PNG con misiones de ejemplo)
```

## Cómo se decide la ruta
Prioridades, en este orden: 1) menos sitios de entrega, 2) menos sitios de recogida, 3) no pasar de la capacidad (y que las
cajas quepan), 4) más aUEC, 5) con recompensa parecida (±5 %), menos paradas. Las alternativas relajan alguna: «Más aUEC»,
«Un solo destino, más aUEC», «Menos paradas». La capacidad se cuenta como suma de todos los SCU del viaje (todo recogido
antes de entregar). Se ajusta en `Ships` de `config.json`.
