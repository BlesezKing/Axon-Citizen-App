# AXON CITIZEN — documento técnico y funcional completo

> Pensado para pasárselo a otra IA (o a un desarrollador) como contexto único para **mejorar la aplicación**.
> Describe qué hace, cómo está construida, en qué datos y fórmulas se basa, qué pantallas y overlays tiene (con especial detalle en **Minería**), qué está verificado y qué es una suposición, y qué queda por hacer.
> Estado documentado: versión **v11** (octubre 2026), parche de datos de minería **4.10.1-LIVE.12660092** (scminer.rocks indica 4.10.2), **483 tests** pasando.

---

## 0. Resumen en 10 líneas

1. Aplicación de escritorio **Windows (C# / .NET 8 / WPF)**, compañera **externa y pasiva** de *Star Citizen*.
2. Solo hace **captura de pantalla + OCR de Windows** y dibuja su propia ventana transparente (overlay). Nada más.
3. **Prohibido por diseño** (riesgo de baneo / Easy Anti-Cheat / ToS de CIG): leer memoria del proceso, inyectar código, tocar archivos del juego, pulsar teclas o mover el ratón dentro del juego, pedir administrador.
4. Módulos: **Hauling** (leer contratos, planificar rutas por aUEC/hora), **Jornadas** (sesiones, estadísticas, CSV), **Tiempos** (aprendizaje de tiempos reales), **Minería** (equipo, overlay con OCR del HUD, bodega, refinado), **Naves** (catálogo + builds por rol), **Mercado** (UEX), **Ajustes**.
5. Datos de la comunidad (UEX 2.0, Star Citizen Wiki API, scminer.rocks) **cacheados localmente**; nunca números de juego cableados en la lógica (van en JSON versionados con parche y fecha).
6. Arquitectura en dos proyectos: `Axon.Core` (lógica pura, testeable, sin UI) y `Axon.App` (WPF + captura + OCR + Win32).
7. UI construida **en código C#** (sin XAML por pantalla) con un sistema de diseño propio (`Ds`), estilo HUD de Star Citizen (cian, esquinas biseladas).
8. Persistencia: JSON en `%AppData%\AxonCitizen\` + SQLite (`naves.db`, `rutas.db`).
9. El OCR es la parte frágil: se mitiga con preprocesado (Chroma/Global/Adaptive), varias variantes y votación, y siempre muestra confianza y permite corregir a mano.
10. Lo más débil hoy: parsers de minería escritos con pocas capturas reales; fórmula de fractura estimada; múltiplos del ping y rendimiento/coste de refinado sin verificar.

---

## 1. Reglas del proyecto (instrucciones permanentes del usuario)

- **Modular**, con tests y explicación de cómo probar en el juego; pedir capturas cuando hagan falta.
- Datos de **APIs de la comunidad** (UEX, Star Citizen Wiki API), cacheados en local, **sin números cableados** en la lógica; respetar límites de las APIs (peticiones espaciadas ≥700 ms, reintentos, `Retry-After`); claves de API en configuración.
- Una ruta de hauling **entrega todo en un único destino**; máximo **10 misiones aceptadas** a la vez.
- **Seguridad**: solo captura + OCR. Marcar siempre lo no verificado.
- **Entrega**: cada versión nueva se entrega como zip (`Downloads\AXON-CITIZEN-app-vN.zip`) **y** se instala descomprimida en `C:\Users\adria\AXON-CITIZEN` con acceso directo `Desktop\AXON CITIZEN.lnk` → `AxonCitizen.exe`. Si la app está abierta (bloquea archivos) no se mata sin avisar: se espera a que el usuario la cierre. Los datos de usuario (`%AppData%\AxonCitizen`) no se tocan.
- Idioma de la interfaz: **español**. Los contratos y el HUD del juego están en **inglés**.

---

## 2. Stack técnico y estructura del repositorio

| Aspecto | Detalle |
|---|---|
| Lenguaje / runtime | C# 12, .NET 8; `Axon.Core` = `net8.0`, `Axon.App` = `net8.0-windows10.0.19041.0` (WPF, `win-x64`, framework-dependent) |
| Paquetes | `Microsoft.Data.Sqlite 8.0.10` (Core), `System.Drawing.Common 8.0.10` (App); tests: xUnit 2.5.3 |
| OCR | `Windows.Media.Ocr` (WinRT), mejor con idioma inglés instalado |
| Captura | GDI (`BitBlt`/`CopyFromScreen` sobre la ventana del juego), excluyendo el propio overlay con `SetWindowDisplayAffinity(EXCLUDEFROMCAPTURE)` |
| Teclas globales | `RegisterHotKey` + sondeo `GetAsyncKeyState` (doble vía, antirrebote) |
| Datos embebidos | `Data/*.json` como `EmbeddedResource` (`Axon.Core.Data.<nombre>`), sobrescribibles copiando a `%AppData%\AxonCitizen\data\` |

```
AxonOverlay/
├─ src/
│  ├─ Axon.Core/                  (lógica sin UI, 100 % testeable)
│  │  ├─ Config/    AppConfig, ConfigStore, BackupService
│  │  ├─ Contracts/ ContractParser, ReadingConsensus, Resolvers, MissionStore, MissionFilter,
│  │  │             MissionValidator, MissionRank, MissionTags, ShipCatalog, UserLocationStore, Models
│  │  ├─ Routing/   DestinationPlanner, TimeModel, PlaceGeo, RouteDb, DistanceSync, TimeLearner,
│  │  │             RunRecorder, RouteGeo, RoutePlan, PlaceNotes
│  │  ├─ Mining/    MiningData, MiningCalc, MiningHud (parsers), MiningEconomy, MiningStore,
│  │  │             ChargeGuide, RefineryTerminal
│  │  ├─ Ships/     ShipDb (SQLite), ShipSync, ApiClient, ShipParsers, ShipModels, RoleCatalog,
│  │  │             BuildAdvisor, BuildMeta
│  │  ├─ Sessions/  WorkSession, SessionStore, SessionStats
│  │  ├─ Market/    MarketData
│  │  ├─ Scan/      ChangeDetector
│  │  ├─ Text/      FuzzyMatcher
│  │  ├─ Input/     HotkeySpec
│  │  ├─ Logging/   Log
│  │  └─ Data/      locations.json, cargo.json, ships.json, mining-*.json, build-meta.json, UexData.cs
│  └─ Axon.App/                   (WPF)
│     ├─ Capture/   ScreenCapture, ImagePrep, WindowsOcr, ContractReader, MissionScanner, MiningWatcher
│     ├─ Interop/   Native (P/Invoke), HotkeyManager, GameWindow
│     ├─ Overlay/   OverlayController (parcial: .cs, .Capture, .Missions, .Rutas, .Extras, .Mining, .MiningHud),
│     │             OverlayWindow, WidgetHost, Widgets (WidgetCatalog + *Content), AppState, MiningLive,
│     │             HudCalibrationWindow, MissionEditorWindow, ThemeService
│     ├─ Pages/     HaulingPage, SessionsPage, TimesPage, MiningPage, ShipsPage, MarketPage, SettingsPage, PageBase
│     ├─ Ships/     ShipsService, ShipBuildView
│     ├─ Theme/     Ds (tokens + componentes), Bevel, DataTable, SplitGrid, Theme.xaml
│     ├─ MainWindow.cs, MissionFilterPanel.cs, App.xaml.cs (arranque + CLI de diagnóstico)
├─ tests/Axon.Tests/   (483 tests) + tests/samples (capturas y respuestas reales de APIs)
├─ tools/              gen-data.ps1, gen-mining-data.ps1, make-ship-fixtures.ps1, verify-samples.ps1
├─ test-assets/mining/ capturas reales aportadas por el usuario (+ README)
├─ docs/mining-research.md · ALGORITMO-DE-RUTAS.md · README.md · AXON-CITIZEN-RESUMEN.md
```

---

## 3. Arquitectura en ejecución

```
Teclas globales ─┐
                 ▼
          OverlayController ◄── AppState (estado compartido: misiones, ruta, jornada, minería en vivo…)
             │   │   │                       ▲
             │   │   └─ MiningWatcher ───────┘  (hilos de fondo: captura zona → ChangeDetector → OCR → parser → Dispatcher)
             │   └──── MissionScanner / ContractReader (captura de contrato → OCR → ContractParser → consenso → MissionStore)
             ▼
   OverlayWindow (transparente, click-through) ── WidgetHost ── *Content (IHudContent)
   MainWindow (navegación lateral) ── Pages/*  (leen/escriben vía OverlayController)
```

- **`OverlayController`** (clase parcial, el «cerebro» de la app): posee configuración, almacenes, lector OCR, escáner, vigilante de minería, planificador. Las páginas y widgets lo consumen; `AppState.Touch()` notifica y los widgets se refrescan.
- **Widgets del overlay**: `WidgetCatalog` define `WidgetDef(id, título, layout por defecto, fábrica de IHudContent)`; `WidgetHost` los coloca/redimensiona/oculta; la posición, tamaño, visibilidad y opacidad se guardan en `config.json`.
- **Páginas**: `PageBase` (Key, Title, View, OnShown, Refresh, Preselect). Se crean en `MainWindow` y se navega por clave: `hauling`, `jornadas`, `tiempos`, `mineria`, `naves`, `mercado`, `ajustes`.
- **Hilos**: la captura/OCR corre en `Task.Run`; los resultados vuelven con `Window.Dispatcher.BeginInvoke`. `WindowsOcr` mantiene un **pool de 4 motores** + `SemaphoreSlim` (un único `OcrEngine` no admite llamadas concurrentes).
- **Solo trabaja con el juego delante**: el vigilante comprueba que la ventana de Star Citizen es la primera (`GetForegroundWindow`) y no está minimizada.
- **CLI de diagnóstico** (`App.xaml.cs`, no abren la UI): `--ocr-test <img> [--out dir]`, `--ocr-text <img> [--zone x0,y0,x1,y1] [--out f]`, `--mining-read <img> [--out f]`, `--ships-sync [--ship X]`, `--geo-sync`, `--snapshot <png> --demo [--edit]`, `--snapshot-main <png> --page <key> --tab N --size WxH`, `--data <dir>` (carpeta de datos alternativa). *Nota:* en la última sesión las ejecuciones por CLI desde la compilación Debug no llegaron a completarse (sin resolver); los tests no las necesitan.

---

## 4. Archivos y persistencia (`%AppData%\AxonCitizen\`)

| Archivo / carpeta | Contenido |
|---|---|
| `config.json` | Teclas, opacidad, color de acento, layout de widgets, naves (perfiles de hauling), zonas de captura de contratos, ajustes de escaneo, sonidos, tiempos (`Time`), estimación por zonas (`Estimate`), **`MiningHud`**, modo de planificador, escala de UI, copia automática, clave UEX opcional |
| `missions.json` | Misiones leídas (con tramos, estado, aviso, hora de lectura) |
| `sessions.json` | Jornadas con misiones completadas, gastos, totales |
| `mining.json` | **Perfiles de equipo de minería**, bodega, presupuestos de refinado, **firmas de ping aprendidas** (`Pings`: valor → mineral) |
| `user-locations.json`, `place-notes.json` | Lugares confirmados por el usuario; notas por lugar (⚠ en pasos de ruta) |
| `naves.db` (SQLite) | Catálogo de naves, huecos, piezas, precios, builds guardadas, registro de cambios |
| `rutas.db` (SQLite) | `places`, `orbits`, `orbit_distance` (distancias reales UEX), tiempos aprendidos, registro de rutas realizadas |
| `market-cache.json` | Precios de mercado cacheados |
| `data\*.json` | Datos actualizados desde UEX o reemplazos (`mining-*.json`, `build-meta.json`, `locations.json`…): tienen prioridad sobre los embebidos |
| `backups\` (20 últimas), `logs\` (14 días), `debug-captures\` (`dudosas\` = 15 últimas lecturas dudosas) | Mantenimiento |

Escritura segura: se escribe a `*.tmp` y se mueve; si un JSON está corrupto se copia a `*.corrupt-<fecha>` y se arranca vacío.

---

## 5. Módulo HAULING (contratos y rutas)

### 5.1 Lectura de contratos
- Origen: pantalla **Contract Manager** del mobiGlas. Zonas configurables (fracciones de la ventana): `Title`, `Reward`, `Details`, `Objectives`, `List` (columna con recompensa redondeada «76k» y tiempo restante).
- Captura → `ImagePrep` (ampliar ×1–4, umbral adaptativo / global / chroma) → `WindowsOcr` → `ContractParser` (título, recompensa aUEC, contratista, descripción, disponibilidad, **caja máxima**, **tramos**: mercancía + SCU + recogidas + destino; varios cargamentos y varias recogidas por tramo; reputación solo si hay línea «Reputation/Rep» con cifra).
- **Consenso** (`ReadingConsensus`): varias variantes de lectura con votación, arbitraje con la lista lateral, reparación de dígitos, rescate de lugares con la descripción.
- **Resolución difusa** (`Resolvers`, `FuzzyMatcher`) contra 134+ lugares (UEX; +398/400 con órbita) y 175 mercancías; ignora ruido típico («. O»); candidatos «¿quisiste decir X?»; lugares confirmados se recuerdan (`UserLocationStore`), sin aprender variantes mal leídas de sitios que ya existen.
- **Validación** (`MissionValidator`): avisos ⚠ (recompensa/SCU sin leer, falta recogida o destino, lugar sin confirmar, recogidas que no suman, tramos idénticos, lectura poco fiable).
- **Antiduplicados** (`MissionStore`): coincidencia difusa por recompensa, nombre, tramos y lugares; una relectura mejora campos pero no resucita completadas ni pisa correcciones manuales.
- Capturas dudosas se guardan solas (`debug-captures\dudosas`).

### 5.2 Modo escaneo
- **F8** inicia/termina. Por defecto (`Scan.Auto=false`): con cada contrato abierto el usuario pulsa **F9** y se captura **una foto**, se lee en orden y el aviso/sonido corresponde a esa misión. Opción `Scan.Auto=true`: lectura automática cuando la pantalla de contrato se estabiliza (`ChangeDetector`: miniatura gris, `PixelDiff` 40, `ChangedPixels` 25, `StablePolls` 2, sondeo 120 ms).
- Sonidos: misión nueva / ya escaneada / fin del escaneo / avisos. Toast grande por misión. Al terminar (F8) calcula rutas.

### 5.3 Ciclo de vida de misiones
Pendiente → aceptada (ruta activa) → completada ✓ / abandonada ⊘. Editor completo (✎), borrado (✕). Máximo 10 aceptadas.

### 5.4 Filtros
«Estoy en», «Recoger en», «Entregar en» (casillas con recuento). Para la lista basta coincidir algún sitio; para planificar la misión debe poder hacerse **entera** con los sitios marcados.

### 5.5 Planificador (`DestinationPlanner`) — ver `ALGORITMO-DE-RUTAS.md`
Reglas duras (filtro previo): pendiente; SCU leídos; cabe en la nave (SCU ≤ capacidad) y en cajas (caja máx. ≤ caja de la nave); **un solo destino de entrega**; filtros; cupo `10 − aceptadas`.
Cuatro modos (`PlannerMode`, por defecto **`Rate`**):

| Modo | Valor | Notas |
|---|---|---|
| **Rate (Máx. aUEC/h)** (por defecto) | maximiza `recompensa / tiempo` | Distancias reales UEX + motor cuántico de la nave + tiempos aprendidos; beneficio mínimo `Time.MinProfit` = 50.000 |
| **Money** | recompensa | tolerancia ruta limpia 100 % |
| **Efficiency** | recompensa − 0,5 × (aUEC medios por SCU) × SCU | tolerancia 85 % |
| **Reputation** | rango del nombre (Trainee<Rookie<Junior<Member<Experienced<Senior<Master) primero, dinero después | solo misiones del rango máximo por destino |

Algoritmo por destino: mochila 0/1 exacta por DP (`dp[k][c]`, k misiones, c SCU) con desempate embebido; candidatos «mejor combinación» y «mejor ruta limpia» (una sola recogida); modo Rate: enumeración de subconjuntos de recogidas (≤14), mochila con `recompensa − λ·t_carga`, orden óptimo de paradas (permutación exacta ≤7, si no vecino más cercano + 2-opt) y **Dinkelbach** (≤12 iteraciones, 1,5 s de presupuesto). Salidas: Recomendada, Más misiones, Menos misiones, Más aUEC, alternativas, desplegable «Otro destino»; explicación comparativa.

### 5.6 Modelo de tiempo (`TimeModel`, `TimeSettings`)
`T = fijo ruta (300 s) + Σ parada (aproximación + gestión/ascensor + cajas) + Σ viajes`.
Viaje quantum = spool + calibración (4 s) + aceleración (derivada del `t10` del motor o 45 s) + `distancia/velocidad` × corrección aprendida; salto entre sistemas 120 s; aproximación estación/ciudad/outpost 120/300/210 s; salida 60/120/60; ascensor 60/90/45; caja = 6 s + 0,5 s·SCU; caja por defecto 4 SCU; distancia misma órbita 0,03 Gm; sin dato 30 Gm (mismo sistema) / 60 (otro).
Distancias: UEX `orbits_distances` (≈3.500 pares) + `space_stations/cities/outposts/poi` para saber la órbita de cada lugar; SQLite `rutas.db`; botón «Refrescar distancias» y descarga automática la 1.ª vez y cada 14 días.

### 5.7 Aprendizaje (`TimeLearner`, `RunRecorder`)
Con una ruta activa **F4** (o botón ⏱) marca: **Salgo → Llegado a X → Carga terminada / Entregado**. Calibra velocidad real del quantum (trayectos ≥5 Gm), aterrizaje (por tipo y por sitio), ascensor y segundos por caja con **media móvil exponencial α=0,2**; descarta valores absurdos (≤0, >4× lo esperado, fuera de 3×MAD). Pantalla **Tiempos**: estimado vs real, aUEC/h real, lo aprendido, borrar.

### 5.8 «Misiones a coger» (`MissionTags`)
En el panel de ruta: cada misión elegida con recompensa en miles (`50k`) y exacta, SCU, mercancía y tiempo restante (`TimeLeft` = disponibilidad leída − tiempo transcurrido) y, debajo, las **gemelas NO elegidas** (mismo nombre + recogidas + destino) con diferencia de recompensa/SCU. Desaparece al pulsar F4 (empezar a cargar; si la ruta no estaba aceptada, la acepta) y vuelve al escanear.

### 5.9 Jornadas
Iniciar/terminar con F7 (o automática al completar la primera misión). aUEC, misiones, SCU, tiempo, aUEC/h, gastos (combustible, reparaciones) → beneficio neto. Historial con detalle, estadísticas (aUEC por día, por contratista, por ruta, mejores jornadas), exportar CSV (`;`, BOM, Documentos\AxonCitizen), copia de seguridad al terminar.

### 5.10 Mercado (UEX)
«Dónde vender», «Dónde comprar», «Mejores rutas comerciales» para la capacidad de la nave (stock/demanda, precios ≤30 días, margen×SCU sin combustible ni tiempo); atajo de minerales/gemas; solo descarga al pulsar «Actualizar precios».

---

## 6. Módulo NAVES

- Catálogo ≈340 naves/vehículos fusionando **UEX** (naves, compra, alquiler, terminales) y **Star Citizen Wiki API** (roles, huecos con pieza de serie, estadísticas, precios de piezas, efectos de módulos). SQLite `naves.db`; funciona sin conexión.
- Datos: fabricante, tamaño, roles (varios), SCU carga y mineral, tripulación, caja máxima, precio compra/alquiler con dónde, fecha y fuente, pledge (informativo). Badges «Comprable/Alquilable/No disponible in-game/Concepto».
- Filtros: rol, disponibilidad, fabricante, tamaño, rango SCU, precio máx.; buscador; orden por columna.
- **Ficha** (Resumen / Dónde conseguirla / Build). **Builds** (`BuildAdvisor` + `Data/build-meta.json`):
  - **Minería**: *Potencia* (Helix I/II; módulos Rieger-C3 + Focus III + Surge), *Estable* (Arbor/Lancet/Hofstede con Focus III + XTR-XL), *Económica* (Hofstede + Focus II + Rieger-C2). Torretas del MOLE expandidas (3 cabezales).
  - **Salvamento**: Baler (o cabezal propio de la Salvation) con Abrade + Cinch (*Equilibrada*) / Trawler + Abrade (*Rápida*).
  - **Resto de roles**: mejor pieza por **estadísticas reales** según el rol (combate: velocidad/preparación cuántica; carga/exploración: menor consumo; sigilo: menos EM) + pequeña bonificación por clase.
  - El meta de la comunidad está en `build-meta.json` (listas de preferencia con enlaces), sustituible en `%AppData%\AxonCitizen\data\`.
  - Builds propias: guardar varias por nave, copiar/importar JSON; cambiar cualquier pieza a mano; coste total vs serie.
- «Usar en el planificador» (capacidad y caja máx.) y «Usar este motor cuántico» (velocidad, spool, t10 → modelo de tiempo).
- Sincronización: «Refrescar» (≈20 MB), «Solo precios» (≈2 MB), «Refrescar nave»; detecta y anota cambios; peticiones espaciadas con reintentos.

---

## 7. Interfaz general

### 7.1 Ventana principal (`MainWindow`)
Barra lateral con 7 secciones: **⛟ Hauling / Planificador · ⏱ Jornadas · ⏲ Tiempos · ⛏ Minería · 🚀 Naves · 📈 Mercado · ⚙ Ajustes**; franja inferior con último aviso y nave activa (clic → Naves). Adaptable a 1080p/1440p/4K (`UiScale`), paneles que se apilan en ventanas estrechas (`SplitGrid`). Cerrarla cierra el programa.

### 7.2 Overlay principal
Ventana transparente siempre encima, normalmente **click-through**; **F11** = modo edición (mover/redimensionar, mostrar/ocultar paneles, opacidad, botones ✓ ⊘ ✎ ✕). Widgets registrados en `WidgetCatalog`:

| Id | Título | Por defecto | Contenido |
|---|---|---|---|
| `missions` | Misiones de hauling | visible | lista de misiones con estado |
| `route` | Ruta | visible | modos, opciones, pasos con checklist, «Misiones a coger», ⏱ |
| `scan` | Escaneo de misiones | visible | estado y cuenta del escaneo |
| `cargo` | Carga | visible | barra de SCU de la ruta (aviso al 90 %) |
| `session` | Jornada | visible | aUEC, misiones, SCU, tiempo, aUEC/h |
| `status` | Estado | visible | último aviso |
| **`mining`** | **Minería** | **oculto** | ver §8.5 |
| `compact` | Resumen | oculto | siguiente paso + carga + jornada (modo compacto) |

### 7.3 Ajustes
Cards: Aspecto (acento, UiScale) · Overlay (opacidad, paneles visibles, compacto, restablecer) · Sonidos · Datos y mantenimiento (CSV, copia, carpeta de datos, notas de lugares, actualizar lugares/naves UEX, aviso idioma OCR) · Naves y precios (clave UEX opcional) · Teclas globales · Estado y diagnóstico · Registro.

### 7.4 Teclas globales

| Tecla | Acción | Config |
|---|---|---|
| F9 | Leer el contrato abierto (captura manual) | `Hotkeys.Capture` |
| F8 | Iniciar/terminar escaneo | `Hotkeys.Scan` |
| F7 | Iniciar/terminar jornada | `Hotkeys.Session` |
| F6 | Marcar siguiente paso de la ruta | `Hotkeys.NextStep` |
| F4 | Marca de tiempos (Salgo/Llegado/Hecho) y «empiezo a cargar» | `Hotkeys.Mark` |
| F10 | Mostrar/ocultar overlay | `Hotkeys.ToggleOverlay` |
| F11 | Modo edición | `Hotkeys.EditMode` |
| **F3** | **Mostrar/ocultar overlay de minería (arranca/para el vigilante)** | `MiningHud.ToggleKey` |
| Ctrl+F3 | Marcar zonas del HUD a mano (**solo plan de emergencia**: el lector automático no lo necesita) | `MiningHud.CalibrateKey` |
| Ctrl+Alt+F12 | Salir | `Hotkeys.Quit` |

### 7.5 Sistema de diseño (`Theme/`)
`Ds.cs` (tokens de color/espaciado/tipografía Bahnschrift, tarjetas biseladas, botones `Kind.Primary/Danger`, insignias, pestañas `Ds.Tabs`, buscador, estados vacío/cargando/error, barras, `Ds.Field`, `Ds.Text`, `Ds.Muted`), `Bevel.cs`, `DataTable.cs` (tabla ordenable con filtro y estado vacío), `SplitGrid.cs` (dos paneles lado a lado o apilados), `Theme.xaml` (estilos base). El overlay usa los mismos colores (`AccentBrush`, `OkBrush`, `WarnBrush`, `BadBrush`, `MutedBrush`, `TextBrush`).

---

## 8. MÓDULO MINERÍA (en detalle)

### 8.0 Lector AUTOMÁTICO del HUD (v11) — sustituye a las zonas fijas

> A partir de la v11 el overlay de minería **no necesita calibración**. Las secciones 8.5–8.7 describen el lector antiguo por zonas fijas, que queda solo como **plan de emergencia** (Ajustes → «Minería · lector del HUD» → «Usar zonas fijas»). El sistema de equipo/perfiles (8.3, 8.4 pestaña Equipo) no ha cambiado.

**Por qué**: el HUD de minería se mueve con la cabeza/cámara, está en perspectiva, cambia con el asiento y el modo y depende de la resolución. Las zonas fijas no valen. El texto mide ~7 px en una captura de 2000 px y Windows OCR (es-ES, sin inglés) no lo lee (1 de 13 campos de la bodega). Ver `docs/ocr-bench-fase0.md`.

**Arquitectura** (`src/Axon.Core/Mining/Hud/` = lógica pura con tests; `src/Axon.App/Capture/Hud/` = captura + OCR):

| Pieza | Fichero | Qué hace |
|---|---|---|
| Motor OCR | `PaddleOcr.cs` | PaddleOCR (det PP-OCRv4 + rec ch-PP-OCRv4) con ONNX Runtime, solo CPU, 2 hilos. Lectura normal y «solo cifras» (restringe clases a `0-9 . , / %`). Modelos en `models\` junto al exe (override en `%AppData%\AxonCitizen\data\models`). |
| Analizador de fotograma | `HudScanner.cs` | Normaliza la captura a ancho fijo 2048 (1080p/1440p/4K), detecta texto a 2 escalas (2048 y 2560, unión por IoU), reconoce cada recuadro con la imagen ORIGINAL, clasifica su color (naranja/cian/blanco/rojo) y hace una 2.ª pasada ampliada (texto ~36 px) sobre los paneles hallados. Lee las calidades celda a celda (cifras blancas sobre recuadro rojo; 3 preprocesados). |
| Vigilante | `HudWatcher.cs` | Hilo de prioridad baja: reposo (10 s) / activo (1 s); en activo relee solo los paneles y cada 6 ciclos hace búsqueda completa. Solo con el juego delante. Modo diagnóstico (captura anotada + texto). |
| Anclas y situación | `HudAnchors.cs` | Palabras fijas (`CARGO`, `MINING LASER`, `SCAN RESULTS`, `CHARGE LEVEL`, `LASER RANGE`, `FRACTURE MODE`, `READY TO SCAN`, `SCAN MODE/MINING MODE (TOGGLE)`, `FIRE (TOGGLE)`, `LASER POWER`, `FOCUS +/-`) con coincidencia difusa; deben ir al principio de su línea (el chat no cuenta). Puntúa escaneo/minería → modo; rol: Piloto si hay `CARGO` o modo escaneo; Operador si hay datos reales en SCAN RESULTS sin bodega. |
| Lectores | `HudReaders.cs` | Bodega (cabecera, filas por altura de texto `u`, nombre → mineral conocido, calidad → solo valores de la tabla del mineral con ≤1 cifra distinta, SCU, comprobación de suma ±0,02, **reparación por suma** de confusiones 0↔8/1↔7/3↔8…, capacidad de la nave como pista), pings, SCAN RESULTS. |
| Interpretación | `HudInterpreter.cs` | De recuadros a `HudAnalysis`; excluye de los pings las zonas de paneles. Probado con recuadros guardados de capturas reales. |
| Pings | `PingInterpreter.cs` + `Data/mining-signatures.json` | Valor = nº de rocas × firma. Se prueban **todas** las tablas (Wiki 4.10.1 + comunidad 4.7), solo múltiplos exactos; si no hay, corrige UNA cifra (6↔8…) y lo marca. Aprendizaje ping→mineral conservado. |

**Independencia de la resolución**: toda la geometría de los lectores va en múltiplos de la altura del texto del ancla (`u`) y en un fotograma de trabajo de ancho fijo; un test escala los recuadros ×0,75/×1,5/×2 y el resultado no cambia. Límite real: legibilidad (texto ≥ ~7 px a 2048 de ancho). Con una captura de 2000 px remuestreada a 1920/2560 la precisión baja (el WebP ya es blando); con 4K simulado y nativa sale completo.

**Resultados medidos** (capturas del usuario, 2000×1125 WebP): piloto·minería → 4/4 filas (Tungsten 363 · 3,73; Inertes 1,97; Tungsten 787 · 1,48; Laranite 510 · 0,51), total 7,70 y capacidad 96 corregidos; piloto·escaneo → ping leído `18720`, corregido a `16720 = 4 × Hephaestanite (4.180)` con la tabla de comunidad 4.7. Tiempos en CPU: búsqueda completa ~4,5 s (det 2,3 s + rec 2 s); relectura de paneles ~0,5–1 s.

**Overlay (widget `mining`, F3)**: cabecera con el rol/modo detectado (o «forzado»); en **escaneo** lista de pings (el principal en grande, detalle, hora, ✔ si es aprendido); en **minería como piloto** valor de la bodega sin refinar en grande, refinado neto, SCU/capacidad/%, «última roca +X · sesión +Y», filas con calidad y valor, confianza y avisos; en **operador** roca, veredicto, ⚡ potencia y consejo de carga. Una lectura solo sustituye a la anterior si tiene confianza ≥70 % y la suma cuadra; el cambio de rol/modo necesita 2 lecturas seguidas (3 para salir a reposo). Opcional: etiquetas dibujadas junto a cada marcador de ping.

**Config** (`MiningHud`): `ActiveIntervalMs` 1000, `IdleIntervalMs` 10000, `FullSearchEvery` 6, `ForceRole`/`ForceMode`, `PingLabels`, `SaveDiagnostics`, `EmergencyFixedZones`.

**Diagnóstico por CLI**: `AxonCitizen.exe --mining-read <img> --out salida.txt` (escribe `salida.txt`, `salida.txt.boxes.json` y `salida.txt.png` con los recuadros y anclas). Variables de entorno: `AXON_RESIZE=1920x1080` simula otra resolución; `AXON_CAP=96` pista de capacidad. Banco de OCR: `tools/ocrbench`.

**Sin verificar / pendiente**: asiento de operador (necesita capturas con SCAN RESULTS lleno, carga en zona óptima y sobrecarga), lectura de CHARGE LEVEL con el lector nuevo (el consejo de carga sigue disponible en el plan de emergencia), tabla de firmas vigente en 4.10, calidades en capturas nativas (la 518 del usuario no está en la tabla de Laranite: 510), rendimiento en CPU con el juego a pleno.

### 8.0b Vía rápida de pings, ramas y cierre (v12)
Ver `ESTADO-Y-CONTINUACION.md` §12. Resumen: los pings ya **no** salen del lector lento; `PingWatcher` busca el icono del marcador por color y forma
cada ~200 ms y hace OCR solo del recorte del número; `PingDecoder` + `PingTracker` confirman con votos de varias lecturas y nunca inventan el mineral
(«Ping X — sin identificar»). La app se organiza en **ramas** (Hauling, Minería): cada una con sus widgets, teclas y procesos. La última bodega/roca/pings
se conservan con «Leído hace…» hasta cambiar de rama. El cierre es ordenado con salvaguarda de 3 s.

### 8.1 Objetivo
Ayudar a minar con **nave** (Prospector, MOLE, Golem; ROC/ROC-DS con S0): saber **si tu equipo rompe la roca, con cuánta potencia darle**, **cuándo soltar el láser**, **qué mineral es**, **cuánto vale tu bodega** y **qué refinado conviene** — leyendo el HUD solo con captura + OCR.

### 8.2 Datos (`Data/mining-*.json`, parche 4.10.1, generados por `tools/gen-mining-data.ps1 [-Cache] [-Fresh]`)
Cada JSON lleva `patch`, `generatedAt`, `sources`, `unverified`. Cargados por `MiningData.Load()` (usuario en `%AppData%\AxonCitizen\data\` tiene prioridad sobre el embebido).

| Fichero | Contenido |
|---|---|
| `mining-equipment.json` | **Láseres** (13 de nave + S0): nombre, tamaño, potencia mín/máx W, alcance óptimo/máx m, rendimiento de extracción, ranuras de módulo, % resistencia, % inestabilidad, % ventana óptima, % filtro de inertes, % tasa de carga, precio aUEC, **`SoloCrackLimitKg`** (scminer). **Módulos** activos (Brandt, Stampede, Surge, Lifeline, Forel, Optimum, Rime, Torpid) y pasivos (Focus I/II/III, Rieger/C2/C3, Torrent I/II/III, Vaux/C2/C3, XTR/L/XL, FLTR/L/XL) con efectos con signo y `powerBoostPct` (juego) o `powerBoostScminerPct` (scminer). **Gadgets** (Sabir, OptiMax, BoreMax, Okunis, Stalwart, Waveshift). |
| `mining-minerals.json` | 26 minerales de nave (+terrestres): rareza (`tier`), **`signatureRS`**, inestabilidad, resistencia, precios UEX medio/máx **bruto y refinado**, `weightScu`, `source` (`ship`…), y tabla de **calidad** (8 valores por mineral, 245–1000, convención F–S/Perfecta de la comunidad) |
| `mining-refining.json` | 9 **métodos** (Cormack, Dinyx, Electrostarolysis, Gaskin, Pyrometric, Kazen, Thermonatic, Ferron, XCR) con valoraciones relativas 1–3 de rendimiento/coste/velocidad y `ReferenceYieldPct` aproximado; **bonos de rendimiento** por mineral y refinería (215 filas, 20 refinerías, −9 % a +13 %) |
| `mining-ships.json` | Naves mineras: mineral SCU, carga SCU, tamaños de cabezal, tripulación (Prospector 32 SCU 1×S1; MOLE 96 SCU 3×S2; Golem 32 SCU 1×S1; ROC 1,2; ROC-DS 3,4 — con conflictos entre fuentes anotados) |

### 8.3 Modelo de cálculo (`MiningCalc`) — **estimaciones declaradas, no fórmulas oficiales**

**Un cabezal (`Head`)**
```
powerMult  = max(0, 1 + Σ powerPct(módulos)/100)
resistencia = F(láser) × F(gadget) × Π F(módulo)        (F(x)=1+x/100)  → multiplicativo
inestabilidad = F(láser) × F(gadget.inst + gadget.laserInst) × Π F(módulo)
ventana       = F(láser) × F(gadget) × Π F(módulo)
tasa de carga = F(láser) × F(gadget.óptima) × Π F(módulo.óptima) × F(módulo.todas)
inertes       = F(láser.filtro) × Π F(−|módulo.inerte|)  (los filtros siempre reducen)
sobrecarga    = Π F(módulo.overchargeRate)
potencia mín/máx = potencia del láser × powerMult
CrackLimitKg  = SoloCrackLimitKg × powerMult / max(0.05, Π F(resistencia de módulos y gadget))
```
- Módulos sobrantes respecto a las ranuras se ignoran con aviso; el gadget añade aviso «usa solo uno por roca».

**Flota (`Fleet`)**
- `ActiveLasers` (0 = todos): con 2 de 3 tripulantes se cuentan solo los **N cabezales con más límite de rotura** (desempate por potencia máx.).
- `TotalPowerMaxW` = Σ potencias máx. (**se asume que se suman**); `TotalCrackLimitKg` = (Σ límites) × `Calibration` (0,3–3, editable).
- `OreScu` = SCU editado o el de serie de la nave.

**Veredicto (`CanFracture`)**
```
effLimit = límite × clamp(0.5 / resistenciaRoca, 0.25, 4)   (solo si resistenciaRoca > 0; referencia 0.5)
ratio = effLimit / masa
Sí (verde) ≥ 1,15 · Justo (ámbar) 0,90–1,15 · No (rojo) < 0,90 · margen declarado ±25 %
```
`SuggestFix`: prueba cada gadget y cada módulo activo en un hueco libre y devuelve el que más sube el ratio.

**Potencia recomendada (`PowerFor`, nuevo en v10)**
```
necesaria  = potenciaMáxEquipo × masa / effLimit                (modelo lineal)
mínima     = max(necesaria, Σ potenciaMín de los láseres)
recomendada = min(máx, max(Σ mín, necesaria × 1,15))            (+15 % de margen)
Feasible   = necesaria ≤ máx    → si no: «No llega: haría falta X W y tu equipo da Y W»
```

> **No verificado**: ninguna fuente publica la fórmula real de fractura; los efectos «parecen multiplicativos» (ejemplo scminer 50 × 1,15 = 57,5); el límite en solitario por cabezal es un dato derivado del simulador de scminer, no del juego; la linealidad potencia↔masa es una suposición; la inestabilidad **no entra** todavía en el cálculo (solo se muestra).

### 8.4 Pantalla «Minería» (ventana principal)
Cabecera: «Minería — Tu equipo, lo que puede romper y lo que vale tu bodega. Datos del parche X (fecha)». Botones: **⛏ Overlay de minería** (F3) y **🎯 Calibrar el HUD** (Ctrl+F3). Dos pestañas:

**Pestaña «Equipo»** (dos tarjetas lado a lado):
- *Barra de perfiles*: «Perfil activo» (combo), «Nombre», Guardar / Nuevo / Eliminar (siempre queda ≥1).
- *Nave* (combo con las naves de `mining-ships.json`; al cambiar crea cabezales por defecto = el láser con más límite que cabe en cada tamaño), **«Capacidad (SCU, editable)»**, **«Calibración»**, **«Láseres sobre la roca»** (Todos (N) / 1 láser / 2 láseres…; deshabilitado con un solo cabezal).
- *Por cabezal*: «Cabezal i · tamaño S · láser» (combo con potencia y límite en kg), un combo por **ranura de módulo** (vacío + módulos activos/pasivos), y «Gadget para la roca (uno solo)».
- *Tarjeta «Resultado del equipo»*: nave y SCU de mineral (+carga); por cabezal: potencia mín–máx, alcance óptimo/máx, módulos usados/ranuras, multiplicadores (resistencia, inestabilidad, ventana, tasa de carga, inertes, sobrecarga), **límite de rotura en solitario**, avisos; «Escenario con N láseres sobre la misma roca: potencia total · límite total»; nota de método; **«Probar una roca»** (masa kg + resistencia % → veredicto coloreado + mejor arreglo sugerido).

**Pestaña «Bodega y refinado»**:
- *Tabla «Bodega»* (`DataTable`): Mineral · SCU · Calidad (valor + tramo F–S/Perfecta) · Sin refinar · Refinado · Neto · Mejor opción. Formulario añadir/actualizar/quitar/vaciar. Resumen: SCU en bodega de la capacidad (inertes), total sin refinar, refinado neto, líneas sin precio; recomendación global «Método en Refinería → neto ≈ X aUEC · Y h».
- *Tarjeta «Presupuestos de refinado»*: mineral, refinería, método, SCU que entran/salen, coste, tiempo (min). **📷 Leer terminal** (captura el juego, `RefineryTerminalParser`, crea un presupuesto por método con rendimiento legible), «Añadir presupuesto», «Borrar todos»; lista con ✕ por presupuesto.

### 8.5 Overlay de minería (widget `mining`, F3)
Panel de 440×360 por defecto, oculto hasta pulsar F3 (al mostrarlo arranca el vigilante; al ocultarlo se detiene). Secciones, de arriba abajo (`MiningContent`):

1. **Cabecera**: `⛏ MINERÍA  ● leyendo / ○ parado` + línea de flota: «Nave · N láser(es) · X W · rompe ≈K kg».
2. **Consejo de carga** (si lectura < 6 s): texto grande coloreado — `⛔ ¡SUELTA YA! Sobrecarga…`, `⚠ Carga 80 y subiendo rápido (+25/s): prepárate a soltar`, zona óptima, «Sin carga: apunta al depósito…», o «Carga N». Si es estimación muestra «estimación: <texto OCR>». Suena `Sound.Warning` en nivel Stop.
3. **ROCA** (si lectura < 5 min, «hace X s»): `Mineral · masa kg · resistencia % · inestabilidad N (DIFICULTAD) · SCU · calidad`; **veredicto** (Sí/Justo/No con ratio); **⚡ potencia mínima/recomendada** en W y % del máximo (o «No llega…»); sugerencia de módulo/gadget; hasta 5 filas de composición `   Mineral xx.x %`; «≈ N aUEC por SCU extraído (sin refinar, medias de UEX)».
4. **PING RS 17.020** (si < 5 min): `✔ valor = Mineral (aprendido de tu escaneo)` o hasta 4 candidatos teóricos `k× Mineral (rareza) · ≈precio aUEC/SCU`; «Ningún mineral encaja…» si no hay.
5. **Bodega**: «Bodega X / Y SCU · N líneas · confianza Z %: revísala» + hasta 2 avisos ⚠ (p. ej. «Las filas suman… la cabecera dice…»).
6. Pie: «Esperando datos del HUD…», «Zonas sin calibrar: bodega, carga, roca, ping (Ctrl+F3)», «Palabras del indicador vistas: …».

### 8.6 Pipeline de lectura del HUD (`MiningWatcher`)
- Dos bucles de fondo: **general** cada `PollMs` = 1000 ms (zonas `cargo`, `rock`, `ping`) y **carga** cada `ChargePollMs` = 300 ms.
- Por zona: captura reducida ×2 (×1 la de carga) a grises → `ChangeDetector(40, 12, 2)` (carga: `(25, 3, 1)`); **solo si cambia y se estabiliza** se hace OCR. Sin juego delante todo se pausa.
- OCR de una zona (`ReadZoneAsync`): se prepara la imagen con varias variantes en serie (GDI+ no admite hilos) y se reconoce en paralelo (texto + **palabras con bounding box**):
  - `CargoVariants`: Chroma ×3, ×4, ×2, Global ×2, Adaptive ×2
  - `TextVariants` (roca, ping): Chroma ×3, Global ×2, Adaptive ×2
  - `ChargeVariants`: Chroma ×4, Adaptive ×3
- **`ImagePrep` modos**: *Adaptive* (umbral adaptativo con imagen integral, radio ≥10, sesgo 10: quita destellos del fondo), *Global* (gris + estiramiento + inversión), **Chroma** (aísla texto de color — verde/ámbar/azul del HUD — sobre fondo gris de asteroides).
- Resultado `ZoneRead(Words, Texts)` con coordenadas en la imagen original → `OverlayController.OnMiningRead` → parser → `ApplyCargo/ApplyRock/ApplyPing/ApplyCharge` en el hilo de UI → `MiningLive` (estado) → widget.

**Zonas por defecto** (fracciones de la ventana del juego; `MiningHudSettings`):

| Zona | Región (x0,y0,x1,y1) | Estado |
|---|---|---|
| Cargo (lista de bodega) | 0,695 · 0,665 · 0,800 · 0,800 | medida con foto de pantalla (no nativa) |
| Charge (indicador «0 - EMPTY») | 0,455 · 0,585 · 0,535 · 0,625 | medida con captura de cabina 2000×1130 |
| **Rock (SCAN RESULTS)** | 0,690 · 0,320 · 0,930 · 0,860 | ajustada a la captura real del usuario (v10) |
| **Ping** | 0,250 · 0,020 · 0,750 · 0,200 | ajustada a la captura real (v10) |

Si una zona no está calibrada a mano (`*Calibrated=false`) se **restablece al valor por defecto** al cargar la configuración. `Ctrl+F3` abre `HudCalibrationWindow`: ventana casi transparente sobre el juego donde se arrastra el ratón por cada zona (guarda fracciones → vale para cualquier resolución); Esc cancela, clic derecho salta.

### 8.7 Parsers (`MiningHudParser`, `RefineryTerminalParser`)

**Panel de la roca — formato REAL (captura del usuario, v10)**
```
SCAN RESULTS
IRON (ORE)
MASS: 9292            ← kg, sin unidad
RESISTANCE: 0%
INSTABILITY: 11.81    ← número sin %
CHALLENGING           ← palabra de dificultad
COMPOSITION   12.59 SCU
4.86%  IRON(ORE)         590     ← porcentaje, mineral, calidad
55.69% IRON(ORE)         381
39.44% INERT MATERIALS     0
```
`ParseRock(text, data)` → `HudRock(MassKg, ResistancePct, InstabilityPct, Quality, Composition[(Mineral,Pct)], Confidence, Name, TotalScu, Qualities[], Difficulty)`:
- Masa: `mass[^\d\n]{0,12}([\d.,]+)[ \t]*(kg|t)?`; `12,345`/`12.345` = miles; `t` ×1000.
- Resistencia: `resist\w*… N %`; inestabilidad con o sin `%`.
- Composición: filas «% nombre [calidad]» (solo si el nombre es mineral conocido o inerte, para ignorar «100% LASER IN»), con fallback a «nombre N %»; **deduplicada** (las variantes OCR repiten el texto).
- Cabecera: mineral bajo «SCAN RESULTS», SCU de «COMPOSITION», dificultad (EASY/MEDIUM/HARD/CHALLENGING/EXTREME/IMPOSSIBLE…).
- Confianza = campos clave leídos / 4; el overlay aplica el resultado solo si ≥ 0,5.

**Ping**: `ParsePing` toma el primer número de 4–5 cifras con separadores (`17,020`, `8 400`) entre 1000 y 99999. `InterpretPing(data, rs, tol=1,5 %, maxRocks=40)`: para cada mineral de nave con firma, `k = round(rs/firma)`, acepta si `|rs − k·firma|/rs ≤ tol`; ordena por error y rareza. **Hipótesis sin verificar**: valor = nº de rocas × firma. Con 17.020 la tabla actual no da múltiplo limpio (solo coincidencia casual Lindinium ×5, 0,12 %). **Aprendizaje (v10)**: si se escanea una roca ≤3 min después de un ping, se guarda `ping → mineral` en `mining.json` (`MiningStore.LearnPing`), y se muestra con ✔ la próxima vez que salga ese valor.

**Indicador de carga**: `ParseCharge` → `HudCharge(Value 0–100, Word, Raw)` desde textos como «0 - EMPTY», «62 - OPTIMAL»; correcciones O→0, I/l→1, S→5.

**Bodega** (`ParseCargo`): une las **palabras de todas las variantes**, las agrupa por **fila (posición Y, tolerancia 0,7 × altura mediana)**, vota por campo: SCU (`\d{1,3}[.,]\d{2}`), calidad (3–4 dígitos, 245–1000, tras `FixDigits`), nombre (similitud difusa con minerales/«INERT MATERIALS»). Cabecera «CARGO 28.28 / 96.00 SCU» (también solo total). **Deducción por calidad**: si el nombre no se lee, se usa la tabla de calidad datamineada para inferir el mineral (marcado «deducido: confírmalo»). **Comprobación de suma** filas vs cabecera (si no cuadra, avisa y baja la confianza). Resultado: `HudCargo(Total, Capacity, Lines, Confidence, Warnings)`. Se vuelca al inventario (`ReplaceCargo`) si confianza ≥ 0,4; las líneas manuales se conservan salvo que el HUD las repita.

**Terminal de refinado** (`RefineryTerminalParser.Parse`): busca el nombre de cada método (con tolerancia por primera palabra, similitud ≥0,8), y en su línea + 3 siguientes extrae `%` de rendimiento, `N aUEC` y una duración (d/h/m/s). **Escrito a ciegas (sin captura real del terminal)**; el resultado se muestra para confirmar.

### 8.8 Consejo de carga (`ChargeGuide.Advise`)
Orden de reglas: palabra de sobrecarga (`OVERCHARGE, OVERCHARGED, CRITICAL, DANGER, UNSTABLE, OVERLOAD`) → **Stop**; palabra de vacío (`EMPTY, NONE`) o valor 0 → info; valor ≥ `ReleaseAt` (90) → **Stop** «¡SUELTA!»; velocidad de subida (últimas 2 lecturas) tal que `v + rate×1,2 ≥ ReleaseAt` → **Warn** «prepárate»; palabra óptima (`OPTIMAL, GOOD, STABLE, IDEAL, PERFECT`) → Ok «zona óptima»; bajada < −2/s → «sube la potencia». Las palabras no reconocidas se anotan en «Palabras del indicador vistas» para ajustar listas. **No conoce la ventana óptima real de cada roca.**

### 8.9 Economía de la bodega (`MiningEconomy.Evaluate`)
- Sin refinar = `RawSellAvgAuec × SCU` (medias UEX; **unidad del precio sin verificar**). Inertes: valor 0. La **calidad no modifica ningún valor** (no hay fuente).
- Refinado con **presupuestos reales**: `ratio = salida/entrada`; `salidaSCU = SCU × ratio`; valor = `salidaSCU × RefinedSellAvgAuec`; coste y tiempo proporcionales; `neto = valor − coste`; `ganancia vs bruto = neto − bruto`.
- Sin presupuestos: **referencia** con `ReferenceYieldPct` del método + bono medio por refinería, sin coste ni tiempo (marcada «referencia sin verificar»).
- `BestGlobal`: agrupa por (refinería, método) y suma el neto de las líneas con presupuesto.

### 8.10 Tests de minería
`MiningTests` (datos, láser/módulos/gadget, flota, `ActiveLasers`, fractura, perfiles, bodega, economía, presupuestos, store, persistencia de firmas) y `MiningHudTests` (panel real, composición sin duplicados, potencia lineal, bodega con OCR real `mining-cargo-sample-1.ocr.txt(.words.json)`, ping, carga, terminal). Capturas reales en `test-assets/mining/`: `cargo-sample-1.png` (foto de pantalla 325×224), `cockpit-fracture-mode-empty-1.webp`, `rock-scan-sample-1.webp`, `ping-sample-1.png`.

### 8.11 Lo medido y lo no medido en minería
| Elemento | Estado |
|---|---|
| Indicador «0 - EMPTY» | leído con Chroma ×4 (a veces «EHPTY») |
| «FRACTURE MODE» | se lee con Global ×2 (no se usa) |
| Cabecera «CARGO … / … SCU» | **no se lee** en la captura de cabina (texto pequeño + marcador «UNKNOWN 18.9km» encima) |
| Lista de carga | cifras OK, nombres rotos → se deducen por calidad; **no medido en captura nativa** |
| Panel SCAN RESULTS | parser probado con el **texto** de la captura; **no medido con OCR sobre los píxeles** |
| Ping 17,020 | parser OK; significado (firma × nº rocas) **sin verificar** |
| Barra de carga en uso (palabras reales) | **suposición** (listas configurables) |
| Terminal de refinado | **sin captura real**; parser a ciegas |

---

## 9. Configuración clave de minería (`config.json → MiningHud`)

```json
{
  "Enabled": true, "PollMs": 1000, "ChargePollMs": 300, "ReleaseAt": 90,
  "Cargo":  {"X0":0.695,"Y0":0.665,"X1":0.800,"Y1":0.800},
  "Charge": {"X0":0.455,"Y0":0.585,"X1":0.535,"Y1":0.625},
  "Rock":   {"X0":0.690,"Y0":0.320,"X1":0.930,"Y1":0.860},
  "Ping":   {"X0":0.250,"Y0":0.020,"X1":0.750,"Y1":0.200},
  "CargoCalibrated": false, "ChargeCalibrated": false, "RockCalibrated": false, "PingCalibrated": false,
  "OverchargeWords": ["OVERCHARGE","OVERCHARGED","CRITICAL","DANGER","UNSTABLE","OVERLOAD"],
  "OptimalWords": ["OPTIMAL","GOOD","STABLE","IDEAL","PERFECT"],
  "EmptyWords": ["EMPTY","NONE"],
  "ToggleKey": "F3", "CalibrateKey": "Ctrl+F3"
}
```
Perfil de equipo (`mining.json`): `{ Name, Ship, OreScu, Calibration, ActiveLasers, Heads:[{Size, Laser, Modules[], Gadget}] }`.

---

## 10. Fuentes de datos y APIs

| Fuente | Uso | Notas |
|---|---|---|
| **UEX Corp API 2.0** (`api.uexcorp.space/2.0`) | terminales, poi, outposts, space_stations, cities, orbits, `orbits_distances`, commodities, `commodities_prices_all`, `commodities_raw_prices_all`, `refineries_methods/yields/capacities/audits`, naves, compra/alquiler | sin clave hoy; clave opcional en Ajustes; ≥700 ms entre peticiones; datos colaborativos (pueden estar desfasados) |
| **Star Citizen Wiki API** (`api.star-citizen.wiki`) | `items` (WeaponMining, MiningModifier, Gadget…), commodities, `v3/vehicles` | parche `4.10.1-LIVE.12660092`; fichas duplicadas (se usa la completa) |
| **scminer.rocks** | `límite de rotura en solitario` por cabezal, potencia de módulos que el juego no trae, parche 4.10.2 | dato derivado de su simulador; sin fórmula publicada |
| starcitizen.tools, timesaver.gg, SC DataHub, MMOPixel, Space4Games | mecánica, calidad, refinado, meta de builds | cruzado; hay conflictos anotados |

Regenerar datos de minería: `powershell -ExecutionPolicy Bypass -File tools\gen-mining-data.ps1 -Fresh` (guardar el `.ps1` en UTF-8 con BOM). Regenerar lugares/mercancías: `tools\gen-data.ps1`.

---

## 11. Pruebas

- **483 tests xUnit** en `tests/Axon.Tests` (parser de contratos, consenso OCR, lugares, almacén, antiduplicados, optimizador y sus modos, filtros, jornadas, estadísticas, copias, mercado, UEX, naves y builds con respuestas reales de las APIs, tiempos y aprendizaje, etiquetas de misión, minería y HUD).
- `tests/samples` + `tools/verify-samples.ps1`: capturas reales de contratos leídas con el OCR real.
- No hay pruebas automatizadas dentro del juego con teclas/clics reales.
- Comandos: `dotnet build src/Axon.App -c Release` · `dotnet test tests/Axon.Tests` · publicación: `dotnet publish src\Axon.App -c Release -r win-x64 --self-contained false`.

**Cómo probar minería en el juego**: F3 → Ctrl+F3 y marca las 4 zonas → apunta a una roca, haz ping y escanea → comprueba en el overlay mineral/masa/resistencia/inestabilidad, composición, ⚡ potencia y, al minar, el consejo de carga; abre la lista de bodega y compara «Bodega X / Y SCU». Las palabras del indicador vistas aparecen al pie.

---

## 12. Limitaciones conocidas y suposiciones (lo importante para quien mejore esto)

1. **OCR** de Windows pierde texto pequeño de color sobre fondo con ruido; la mitigación (Chroma, ampliar, votar) no es perfecta. Recomendar inglés instalado.
2. **Fractura**: fórmula estimada (límite en solitario × potencia / resistencia, suma de cabezales, calibración manual); inestabilidad no usada; sin ventana óptima por roca.
3. **Potencia recomendada**: lineal + 15 % de margen; sin verificar en el juego.
4. **Ping**: múltiplos de firma sin verificar; solo aprendizaje empírico fiable.
5. **Precios de minerales**: unidad (por SCU o por unidad) sin verificar; la calidad no afecta al precio (no hay fuente); no hay saturación ni impuestos.
6. **Refinado**: rendimiento base, coste y tiempo reales no publicados; solo valen los presupuestos que el usuario introduce o lee del terminal; parser del terminal sin capturas.
7. **Conversión masa → SCU** no publicada: no se estiman «SCU extraíbles».
8. **Hauling**: reputación real no legible (se usa el rango del nombre); el tiempo mejora con tus marcas; las primeras estimaciones son orientativas; ruta de un único viaje y un único destino por diseño.
9. **Teclas**: F-teclas pueden no llegar si el juego corre como administrador o requieren Fn.
10. **Ventana**: el juego debe ir en **ventana sin bordes**.
11. En el log se ha visto una excepción al cerrar (`InvalidOperationException` por cerrar una ventana mientras ya se cierra, `MainWindow.ForceClose` ← `OverlayController.Quit` ← `OnClosing`): inocua (se captura) pero conviene corregir con una bandera de cierre.

---

## 13. Ideas de mejora (priorizadas)

**Minería**
1. Capturar y medir con el OCR real: panel SCAN RESULTS, ping, barra de carga en uso, terminal de refinado → ajustar regex y zonas; guardar fixtures en `tests/samples`.
2. Medir la **relación real** potencia ↔ masa/resistencia/inestabilidad con datos del usuario («Calibración» automática a partir de aciertos y fallos).
3. Incorporar **inestabilidad** y la **ventana óptima** al consejo de potencia y a «cuándo soltar».
4. Estimar SCU extraíbles (masa → SCU) y valor total de la roca con composición × calidad × precio.
5. Compararlas rocas del cluster por valor/hora; historial de rocas y de aciertos/fallos.
6. Refinado: guardar presupuestos reales por refinería/método para recomendar con datos propios; avisos de trabajos terminados.
7. Selección automática del perfil según la nave en uso; módulos consumibles (usos restantes).

**General**
8. Cerrar el aprendizaje de **tiempos**: prever caducidad de misión frente a tiempo de ruta; verificar misiones aceptadas; combustible/beneficio neto.
9. Mejorar lugares dudosos y misiones con recompensa sin leer (OCR de recompensa).
10. Otros tipos de misión (salvamento, bounties) reutilizando captura + OCR + `WidgetCatalog`.
11. Robustez: corregir la excepción de cierre, CLI de diagnóstico estable, telemetría local de errores de OCR.
12. UX: asistente de primera ejecución (instalar inglés OCR, calibrar zonas, elegir nave).

---

## 14. Cómo extender (guía rápida)

- **Nuevo widget de overlay**: clase `XContent : IHudContent` (`View`, `Refresh()`) en `Widgets.cs` + `WidgetDef` en `WidgetCatalog.All`; lee de `AppState`.
- **Nueva zona de OCR**: región en `MiningHudSettings`/`CaptureRegions` + `Normalize()` + paso en `HudCalibrationWindow` + entrada en `MiningWatcher.Loop` + parser en `Axon.Core` + test con texto real.
- **Nuevo dato de minería**: añadir al JSON (o a `gen-mining-data.ps1`), a `MiningData` (record + lista), y cubrirlo en `MiningCalc`; documentarlo en `docs/mining-research.md`.
- **Nuevo parser de contrato**: `Axon.Core/Contracts` + modelo + resolver; la captura/OCR se reutilizan.
- **Nueva página**: heredar `PageBase`, registrarla en `MainWindow` (`_pages.Add`) y en `BuildNav`.
- **Regla de oro**: toda cifra de juego va en datos versionados con parche y fecha; lo no verificado se marca como estimación en UI y documentación.
