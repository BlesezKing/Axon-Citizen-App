# Relé de salas (opcional)

Solo hace falta si vais a jugar **por internet sin VPN**. Con el modo «Anfitrión / Entrar en el PC de otro» (misma red, Tailscale, Hamachi…) no se necesita.

El relé solo reenvía mensajes **cifrados** (clave derivada del código de la sala, AES-256-GCM): no puede leerlos ni guarda nada.

## Desplegar (gratis, cuenta de Cloudflare)

```
npm i -g wrangler
wrangler login
wrangler deploy
```

Te da una dirección tipo `https://axon-relay.<tu-usuario>.workers.dev`. En AXON CITIZEN → Ajustes → «Minería · sala compartida» pon
`wss://axon-relay.<tu-usuario>.workers.dev` en «Relé» (mismo valor en los dos PCs), uno pulsa «Crear sala» y pasa el código al otro, que pulsa «Entrar con este código».

> Sin verificar: este Worker no se ha podido desplegar ni probar desde aquí; el cliente sí está probado contra un relé WebSocket local equivalente.
