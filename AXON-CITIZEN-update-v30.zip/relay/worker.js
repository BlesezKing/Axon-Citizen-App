// Relé de salas de AXON CITIZEN (Cloudflare Worker + Durable Object).
// Solo reenvía líneas de texto ya CIFRADAS entre los que están en la misma sala (/room/<id>). No guarda nada ni puede leerlo.
export class Room {
  constructor(state) { this.state = state; }
  async fetch(request) {
    if (request.headers.get("Upgrade") !== "websocket") return new Response("Se esperaba WebSocket", { status: 426 });
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.state.acceptWebSocket(server);              // hibernable: no cuesta nada cuando la sala está en silencio
    return new Response(null, { status: 101, webSocket: client });
  }
  webSocketMessage(ws, message) {
    if (typeof message === "string" && message.length > 200000) return;
    for (const other of this.state.getWebSockets()) {
      if (other !== ws) { try { other.send(message); } catch (_) {} }
    }
  }
  webSocketClose(ws, code) { try { ws.close(code, "bye"); } catch (_) {} }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const m = url.pathname.match(/^\/room\/([0-9a-f]{16,64})$/);
    if (!m) return new Response("AXON CITIZEN relay", { status: 200 });
    const id = env.ROOM.idFromName(m[1]);
    return env.ROOM.get(id).fetch(request);
  },
};
