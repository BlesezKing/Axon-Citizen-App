# AXON CITIZEN — Guía: sala compartida y calculadora de rotura

Guía corta para minar en pareja (piloto + operador) con dos PCs. Todo lo que dice la app sobre la rotura sale de las reglas de la calculadora comunitaria **y no está verificado en el juego** hasta que lo calibres tú (apartado 4).

## 1. Poner el equipo (una vez)
1. Abre **Minería → Equipo**.
2. Elige la nave (p. ej. MOLE) y, en cada cabezal, el láser y los módulos.
3. En cada cabezal rellena **Puesto** (p. ej. «Torreta central», «Atrás») y **Persona**.
   - Dos cabezales con el **mismo puesto** = esa persona puede cambiar entre ellos.
4. Marca **Gadgets que tenéis**. Sin marcar ninguno, la app supone que podéis usar cualquiera.
5. Si hoy falta alguien, desmarca **Puesto ocupado hoy** en su cabezal.

## 2. Montar la sala (sin IP ni puertos)
Los dos PCs necesitan internet y la misma versión de la app. Ajustes → **Minería · sala compartida**.

1. Escribe **Tu nombre** (pon ese mismo nombre en «Persona» del cabezal que lleves: así la app sabe cuál es tu línea y la resalta con ▶).
2. **Uno** pulsa **Crear sala**: sale un **código** de 6 caracteres (p. ej. `K7M-2QX`). Pulsa **Copiar código** y pásaselo a tu compañero.
3. **El otro** lo escribe en «Unirme» y pulsa **Unirme**. Ya estáis en la misma sala.

Y nada más. La app encuentra sola cómo conectaros; no tocas IP, puertos ni cortafuegos.

Notas:
- Lo que viaja son solo números ya leídos (pings, bodega, roca, equipo), cifrados con el código. Nunca capturas. Como «buzón» se usan servidores públicos de mensajería (HiveMQ, EMQX, Mosquitto): no pueden leer nada, pero guarda el código para vosotros.
- Si se corta internet, vuelve solo cuando regresa. Al abrir la app, **vuelves a entrar solo en tu última sala** hasta que pulses «Salir de la sala».
- Verás la sala (y quién está) en el overlay de minería y en la página Minería (botón «👥 Sala»).
- **Opciones avanzadas** (escondidas): servidor propio, o que un PC haga de servidor en red local/VPN. No hace falta para jugar.

## 3. Qué verás mientras minas
- **Pings**: el ping que ve tu compañero aparece en tu lista como «visto hace…».
- **Bodega**: la lee quien tenga el HUD de minería (normalmente el piloto); el otro la ve igual.
- **Roca**: quien la escanea la comparte; cada uno recibe el reparto calculado con el equipo de la sala.
- **Reparto (sección ROCA)**: «Torreta central (Tú): Helix II — quieta 68 % · sube 78 % · baja 58 %», el resto fijo al 100 %, y qué puestos no necesitan láser.
- **Línea ↻**: corrige el % según lo que hace la barra de carga (sube → baja el %; baja → súbelo).
- **GADGET**: si hace falta uno, cuál arregla la roca; solo uno por roca (con dos puede explotar).
- **Equipo compartido**: quien edite su equipo en Minería lo comparte con la sala (gana el último). También puedes pulsar **Enviar mi equipo a la sala**.

## 4. Calibrar con tu juego (lo que más ayuda)
1. Escanea una roca **justa** (que el cálculo diga que rompe por poco).
2. Mínala con el reparto indicado.
3. En **Minería → Equipo → Calibrar la potencia**, pon el % de potencia que aplicaste y pulsa **✔ Rompió** o **✖ No rompió**.
4. Con 3–5 medidas la app ajusta un factor de potencia y recalcula la roca. «Borrar medidas» vuelve al modelo original.
5. Si estáis en la sala, tu medida se comparte: el otro PC la añade solo (no hace falta que la anote también).

Además la app anota en `data\calibracion-rotura.jsonl` cómo se comportó la barra con cada plan, para ajustes futuros.

## 5. Si algo falla
- **No conecta**: comprueba que los dos tenéis internet y que el código está bien escrito; el mensaje de error sale en Ajustes bajo la sala y en el registro.
- **No llegan datos**: los dos deben estar en la rama **Minería** y con el lector activo; el registro anota «Sala: recibido «ping» de X».
- **No llega nada y no hay error**: comprueba que la hora de Windows de los dos PCs esté sincronizada (la sala descarta mensajes con más de 10 min de diferencia).
- **El reparto dice «NO ROMPE»**: prueba otra roca, sumad un láser, o mirad el consejo de gadget.

## 6. Entrenar la calculadora (que acierte cada vez más)
Si los % que propone no te cuadran con lo que ves en el juego, enséñale:
1. Escanea la roca y, en **Minería → Equipo → Entrenar la calculadora con tu juego**, elige el **láser que estás tocando** y a qué **%** lo tienes (los demás se suponen al 100 %).
2. Pulsa **▲ La barra SUBE**, **● Se MANTIENE** o **▼ La barra BAJA** según lo que haga la barra de carga con ese %.
   - Con solo «a 20 % sube y a 18 % baja» ya le sirve: cuantos más % distintos, mejor.
   - O marca **Aprender solo de la barra**: dices a qué % estás y ella anota sola si la barra sube, baja o se mantiene.
3. **Sin salir del juego**, con teclas: `Ctrl+Alt+PageUp` = la barra SUBE · `Ctrl+Alt+End` = se MANTIENE · `Ctrl+Alt+PageDown` = BAJA · `Ctrl+Alt+↑/↓` = tu % ±1 · `Ctrl+Alt+→` = otro láser. Suena un pitido al anotar. Si te equivocas: **↶ Deshacer la última** en la página.
4. La próxima vez el reparto ya cuenta con lo aprendido (verás «IA: Hofstede ×0,93 (3)» en el overlay). «Borrar aprendizaje» vuelve al modelo original.

Es un ajuste explicable de la potencia real de cada láser y de cuánto pesa la inestabilidad, no una caja negra: con pocas observaciones se mueve lo mínimo.

### El % del láser se lee solo
El HUD del juego enseña el **% de intensidad de tu láser** («100 % LASER INTENSITY», junto al arco de carga). La app lo lee sola: no hace falta que teclees tu %. Si estáis en la sala, cada uno comparte el de su puesto, así que la calculadora conoce los % reales de todos. Verás «⚡ Láser al N %» en el overlay. Con **Aprender solo de la barra** activado, entrena sola con esos datos.

## 7. Actualizaciones
Ajustes → **Actualizaciones**: pega la dirección del `latest.json` de tu repositorio de versiones. La app busca sola una versión nueva, la descarga y la instala al cerrarla (o con **Reiniciar y actualizar**). Tus datos no se tocan.
