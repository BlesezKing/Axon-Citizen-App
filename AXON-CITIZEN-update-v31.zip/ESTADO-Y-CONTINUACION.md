# AXON CITIZEN — estado del proyecto y cómo continuarlo en otra sesión

> Documento de relevo. Léelo entero antes de tocar nada. Última actualización: **2026-10-11**, versión **v13**, **483 tests** pasando (455 en `Axon.Tests` + 28 en `Axon.App.Tests`).
> Documentación técnica completa: `AXON-CITIZEN-DOCUMENTO-COMPLETO.md` (qué hace cada módulo y en qué se basa). Este documento dice **dónde se quedó el trabajo** y **cómo seguir**.

---

## 1. Qué es (en 5 líneas)

Compañero **externo y pasivo** de Star Citizen para Windows (C# / .NET 8 / WPF). Solo **captura de pantalla + OCR** y dibuja su propio overlay transparente. **Prohibido** por diseño: leer memoria del juego, inyectar código, tocar archivos del juego, pulsar teclas o mover el ratón dentro del juego, pedir administrador (riesgo de baneo / Easy Anti-Cheat / ToS).
Módulos: Hauling (contratos + rutas por aUEC/hora), Jornadas, Tiempos (aprendizaje), **Minería** (equipo, bodega/refinado y **lector automático del HUD**), Naves (catálogo + builds), Mercado, Ajustes. Interfaz en español; el juego está en inglés.

## 2. Dónde está todo

| Qué | Dónde |
|---|---|
| **Proyecto (código, tests, docs)** | `C:\Users\adria\AXON-CITIZEN-PROYECTO` (copia persistente; el original estaba en una carpeta temporal de la sesión que se borra al cerrarla) |
| App instalada | `C:\Users\adria\AXON-CITIZEN` + acceso directo `Desktop\AXON CITIZEN.lnk` → `AxonCitizen.exe` |
| Carpeta de publicación (stage) | `C:\Users\adria\axt-stage\AXON-CITIZEN` |
| Zips de versiones | `C:\Users\adria\Downloads\AXON-CITIZEN-app-v8.zip … v13.zip` |
| Datos de usuario (no tocar) | `%AppData%\AxonCitizen\` (config, missions, sessions, mining.json, naves.db, rutas.db, logs, debug-captures) |
| Página privada de descarga (artifact) | https://claude.ai/artifact/WnfpVL2uDiHmbZo1EswYLS (v11 en 4 partes; solo la abre el dueño) |
| Capturas reales para tests | `test-assets\mining\` (WebP/PNG del usuario) y `tests\samples\mining-hud\*.boxes.json` (recuadros leídos) |
| Modelos de OCR | `tools\ocrbench\models\` (det_v4.onnx, rec_ch_v4.onnx, rec_en_v3.onnx, diccionarios, eng.traineddata). **Imprescindibles para compilar la app** (el csproj los copia a `models\`). |

## 3. Reglas permanentes del usuario (respétalas siempre)

1. **Seguridad**: solo captura + OCR; nada de memoria/inyección/archivos del juego.
2. **Modular**, con tests, y explicar **cómo probarlo en el juego**; pedir capturas cuando hagan falta.
3. **Datos de APIs de la comunidad** (UEX 2.0, Star Citizen Wiki API, scminer) cacheados en local; **nunca cifras de juego cableadas** en la lógica (van en JSON con parche y fecha; lo no verificado se marca). Respetar límites de las APIs (≥700 ms entre peticiones). Claves en configuración.
4. Una ruta de hauling **entrega todo en un único destino**; **máx. 10 misiones aceptadas**.
5. **Entrega de cada versión**: zip en `Downloads\AXON-CITIZEN-app-vN.zip` **y** descomprimida/instalada en `C:\Users\adria\AXON-CITIZEN` con el acceso directo del escritorio. Si `AxonCitizen.exe` está en marcha (bloquea archivos) **no matarlo**: avisar y esperar a que el usuario lo cierre o diga «instala».
6. **Preguntar antes de decisiones de diseño importantes**; marcar siempre lo no verificado.
7. El usuario **no toca** el sistema de equipo/perfiles de minería (nave, láseres, módulos, gadgets, flota, bodega y refinado): funciona y se mantiene.
8. Dar el resultado en español, directo.

## 4. Historia resumida (qué se hizo)

| Versión | Contenido |
|---|---|
| ≤ v7 | Hauling completo (lectura de contratos con OCR, consenso, antiduplicados, escaneo F8/F9, planificador con 4 modos, modelo de tiempo con distancias reales UEX y aprendizaje F4, jornadas, estadísticas, mercado, naves y builds por rol). |
| v8 | **Minería** fases 1–3: datos (`mining-*.json`), pantalla Equipo/Bodega y refinado, overlay con zonas fijas (F3, calibrar Ctrl+F3), consejo de carga, terminal de refinado (📷). |
| v9 | Selector «Láseres sobre la roca» (`MiningProfile.ActiveLasers`: con 2 de 3 tripulantes cuentan los N cabezales más fuertes). |
| v10 | Lector del panel real SCAN RESULTS (formato `MASS: 9292`, `INSTABILITY: 11.81`, filas `55.69% IRON(ORE) 381`), **potencia recomendada** (`MiningCalc.PowerFor`), aprendizaje ping→mineral, zonas por defecto ajustadas. Página de descarga para otro PC. |
| **v13** | **Fase 1 de minería**: detección de pings sin falsos positivos y de ≤0,4 s, y tarjeta de ping rehecha (mineral ×N, imagen, rareza, precios por SCU de UEX, historial). Detalle en §13. |
| **v12** | **Cuatro arreglos**: (1) pings por una **vía rápida** (icono + recorte del número, ~0,3 s) sin falsos positivos; (2) **ramas** (pantalla de inicio, overlay y procesos por rama); (3) la **bodega y los pings no desaparecen** («Leído hace…»); (4) **cierre limpio** del proceso. Detalle en §12. |
| **v11** | **Lector AUTOMÁTICO del HUD** (sin calibrar): banco de OCR, PaddleOCR/ONNX, localizador por anclas, rol y modo, bodega con valor, pings con tablas de firmas, overlay rediseñado, ajustes, diagnóstico. |

## 5. Estado del lector automático (v11 + vía rápida de pings de v12)

Piezas (ver §8.0 del documento completo):
`src/Axon.Core/Mining/Hud/` → `HudModels`, `HudAnchors`, `HudReaders`, `HudInterpreter`, `PingInterpreter` (+ `Data/mining-signatures.json`); `src/Axon.App/Capture/Hud/` → `PaddleOcr`, `HudScanner`, `HudWatcher`; `Overlay/OverlayController.MiningAuto.cs`, `MiningLive.cs`, `Widgets.cs (MiningContent)`, `OverlayWindow.SetPingLabels`; `Pages/SettingsPage.cs` (card «Minería · lector del HUD»).

Resultados medidos **sobre las dos capturas reales del usuario** (2000×1125 WebP):
- Piloto·minería: 4/4 filas exactas (Tungsten 363·3,73 / Inertes 1,97 / Tungsten 787·1,48 / Laranite 510·0,51), total 7,70 y capacidad 96 corregidos por suma.
- Piloto·escaneo: ping leído `18720` → corregido a `16720 = 4 × Hephaestanite (4.180)` con la tabla de comunidad 4.7.
- Tiempos CPU: búsqueda completa ~4,5 s; relectura de paneles ~0,5–1 s.

**NO verificado dentro del juego**: nada del lector automático se ha probado todavía en una sesión real de Star Citizen.

## 6. Pendiente (por orden de prioridad)

1. **Probar v12 en el juego** (rama Minería; pings, bodega que se queda, cierre). Ver §12 «Cómo probar cada punto».
1b. (v11) **Probar el lector en el juego** (F3 sin calibrar). Si falla: activar «Guardar diagnóstico» (Ajustes → Minería) y revisar `%AppData%\AxonCitizen\debug-captures\mineria\*.png/.txt`.
2. **Capturas nativas PNG sin comprimir** del usuario (a su resolución real: ¿1080p/1440p/4K?) de: bodega de piloto, ping en modo escaneo (cluster conocido), y **asiento de OPERADOR** con SCAN RESULTS lleno, cargando en zona óptima y en sobrecarga. Guardarlas en `test-assets\mining\` y repetir `--mining-read`. Las dos actuales llegaron a 2000 px (el chat las reduce) y el WebP es blando: 1080p/1440p remuestreados degradan (pierde calidades o la bodega).
3. **CHARGE LEVEL con el lector nuevo** (consejo «¡SUELTA!»): hoy solo funciona en el plan de emergencia (zonas fijas). Necesita capturas de operador.
4. **Verificar la tabla de firmas de ping en 4.10**: la de comunidad (4.7) encaja con 16.720; la Wiki (4.10.1) no. Aprender más pings con escaneos reales (`mining.json → Pings`).
5. **Calidad**: el usuario leyó 518 en Laranite y la tabla datamineada trae 510 → confirmar si la tabla es la de 4.10.
6. **Rendimiento**: medir FPS del juego con el lector activo; ajustar `IdleIntervalMs/ActiveIntervalMs/FullSearchEvery` y hilos de ONNX si hiciera falta.
7. Compartir datos **piloto ↔ operador** (propuesto, NO implementado): sala por código de 6 caracteres, relay mínimo por WebSocket o LAN, paquetes `{rol, roca, pings, bodega, hora}`. Esperando visto bueno del usuario.
8. ~~Excepción al cerrar~~ **Resuelto en v12** (bandera de cierre, cierre fuera del evento, vigilantes con `Join`, salvaguarda de 3 s).
9. Limpieza: `MiningWatcher` + zonas fijas siguen como plan de emergencia; cuando el lector automático esté validado se pueden retirar.
10. Ideas de hauling aún sin hacer: caducidad de misión frente a tiempo de ruta, verificar misiones aceptadas, combustible/beneficio neto, otros tipos de misión (salvamento, bounties).

## 7. Cómo trabajar con el proyecto

```powershell
cd C:\Users\adria\AXON-CITIZEN-PROYECTO
dotnet build src\Axon.App -c Release          # compila (la app es net8.0-windows10.0.19041.0, win-x64)
dotnet test tests\Axon.Tests                  # 455 tests (xUnit, núcleo)
dotnet test tests\Axon.App.Tests              # 28 tests (WPF: capturas reales + OCR PaddleOCR + ramas + widget)
dotnet publish src\Axon.App -c Release -r win-x64 --self-contained false -o C:\Users\adria\axt-stage\AXON-CITIZEN
```

**Nueva versión (procedimiento)**: compilar + tests → publicar en el stage → copiar `README.md`, `AXON-CITIZEN-RESUMEN.md`, `ALGORITMO-DE-RUTAS.md`, `AXON-CITIZEN-DOCUMENTO-COMPLETO.md` al stage → `Compress-Archive` a `Downloads\AXON-CITIZEN-app-vN.zip` → si `AxonCitizen` no está en marcha, copiar el stage a `C:\Users\adria\AXON-CITIZEN` y comprobar el acceso directo → actualizar la página de descarga (artifact, ver §2; el zip va en base64 troceado en `.txt` ≤ 16 MB cada uno porque el visor no admite `.zip`).

**Diagnóstico por línea de comandos** (usar el exe de **Release** `src\Axon.App\bin\Release\net8.0-windows10.0.19041.0\win-x64\AxonCitizen.exe`; el de Debug se cuelga):

```powershell
AxonCitizen.exe --mining-read <imagen> --out salida.txt   # escribe salida.txt, salida.txt.boxes.json y salida.txt.png (recuadros y anclas)
# variables de entorno: AXON_RESIZE=1920x1080 (simula otra resolución), AXON_CAP=96 (capacidad de la nave)
AxonCitizen.exe --ocr-text <imagen> [--zone x0,y0,x1,y1] --out f.txt
AxonCitizen.exe --ships-sync | --geo-sync | --snapshot x.png --demo | --snapshot-main x.png --page mineria --size 1600x1000 | --data <carpeta>
```
Banco de OCR: `tools\ocrbench` (`dotnet build -c Release`; `OcrBench.exe <raiz> [full]`); resultados en `docs\ocr-bench-fase0.md`.
Datos de minería: `powershell -ExecutionPolicy Bypass -File tools\gen-mining-data.ps1 -Fresh` (guardar los `.ps1` en UTF-8 **con BOM**).

## 8. Trampas conocidas (te ahorran horas)

- El **guardia de rutas** de la herramienta PowerShell bloquea con falsos positivos («Remove-Item on system path…»): evita `Remove-Item`, `///` y `Env:\` en comandos; edita archivos con las herramientas Edit/Write y usa `Move-Item`/`Compress-Archive -Force`.
- `AxonCitizen.exe` en marcha **bloquea** los archivos de `C:\Users\adria\AXON-CITIZEN`: comprobar `Get-Process AxonCitizen` antes de instalar.
- El **Debug** exe del CLI no termina; usar Release. El CLI tarda ~10 s por imagen.
- Windows OCR del usuario solo tiene **es-ES** (sin inglés). Windows OCR **no sirve** para el HUD; el motor es PaddleOCR.
- Los WebP se cargan con el decodificador de WPF (`BitmapDecoder`), no con GDI+.
- `System.Drawing`/WPF dan ambigüedades (`Color`, `Brushes`, `Region`): usa alias o evita `using System.Drawing` en ficheros WPF.
- El proyecto compila los modelos desde `tools\ocrbench\models`: si faltan, la compilación falla.
- La calidad **no cambia el precio** (no hay fuente); la potencia y los efectos combinados son **estimaciones**; la fórmula real de fractura no está publicada.

## 9. Fuentes de datos

UEX Corp API 2.0 (`api.uexcorp.space/2.0`), Star Citizen Wiki API (`api.star-citizen.wiki`, parche 4.10.1-LIVE.12660092), scminer.rocks (4.10.2, límites de rotura en solitario), sc-mining-hud (firmas RS 4.7), starcitizen.tools, timesaver.gg. Detalle y estado de verificación en `docs\mining-research.md`.

## 10. Prompt para arrancar la nueva sesión (copiar y pegar)

> Continúo el proyecto **AXON CITIZEN** (C# .NET 8 WPF, compañero pasivo de Star Citizen: solo captura de pantalla + OCR). El proyecto está en `C:\Users\adria\AXON-CITIZEN-PROYECTO`. Lee primero `ESTADO-Y-CONTINUACION.md` y después `AXON-CITIZEN-DOCUMENTO-COMPLETO.md` (sección 8.0) y `docs\mining-research.md`. Respeta las reglas permanentes del §3 (seguridad, datos versionados, entrega en zip **y** instalación en `C:\Users\adria\AXON-CITIZEN`, no matar la app en marcha). Estado: v13, 483 tests. Lo siguiente es: [probar el lector automático en el juego / procesar las capturas nativas que te paso / operador y CHARGE LEVEL / …]. Antes de decisiones de diseño importantes, pregúntame.

## 11. Si en el otro ordenador no está la carpeta del proyecto

Descomprime `AXON-CITIZEN-PROYECTO-v12.zip` (contiene código, tests, documentación, capturas de prueba y los modelos de OCR) en `C:\Users\<tu-usuario>\AXON-CITIZEN-PROYECTO`, instala el SDK de .NET 8 y ejecuta los comandos del §7. Para solo usar la app, instala el .NET 8 Desktop Runtime y descomprime `AXON-CITIZEN-app-v12.zip`.

## 12. v12 — los cuatro arreglos (qué cambió, dónde está y cómo probarlo)

### 12.1 Pings: vía rápida, sin falsos positivos
- **Causa del retraso** (`HudWatcher`): los pings solo salían de la búsqueda completa de pantalla (≈4,5 s de CPU), que corre 1 de cada `FullSearchEvery=6` ciclos de ~1–3 s ⇒ 8–20 s de retraso típico.
- **Causa de los falsos positivos** (`HudReaders.ReadPings` + `HudInterpreter`): cualquier recuadro de 4–5 cifras que no fuera cian/verde/rojo y cayera fuera de las zonas excluidas valía si tenía forma `\d[.,]\d{3}` (¡«1,250 m» o «5.0km»!), y `PingInterpreter` rellenaba con el mineral **más parecido** (hasta 1,5 %).
- **Ahora**: `Capture/Hud/PingWatcher` (hilo propio, ~200 ms) → `PingReader` → `Core/Mining/Hud/PingIconDetector` (color+forma del icono naranja con cifras pegadas, ~4–10 ms, sin OCR) → OCR **solo del recorte** del número (6 variantes de preparación) → `PingDecoder` (votos, valores válidos = múltiplos de las firmas, una corrección permitida y declarada) → `PingTracker` (confirmación, movimiento, «visto hace…»).
- **Formato estricto** (`PingText`): `16,720` o 4–5 cifras seguidas, rango válido; nada de `km`, `K`, `m`, nombres. `MiningHud.PingRequireSeparator` lo hace aún más estricto.
- **Sin inventar**: si no encaja con ninguna firma → «Ping 12,345 — sin identificar»; los parecidos (≤1,5 %) salen solo como «posibles» con su grado de encaje (`PingInterpretation.Approx`).
- **Diagnóstico**: `debug-captures\mineria-pings\pings.log` (JSON por detección: hora, lecturas de cada variante, posición, recorte, ms hasta mostrarlo) + recortes PNG de lo descartado/dudoso (siempre) y de todo (con «Guardar diagnóstico»). La búsqueda lenta anota «número con aspecto de ping SIN icono (descartado)» en su `.txt`.
- **Medido** (esta máquina, captura real 2000×1125): detección de iconos 4–10 ms; OCR del recorte 50–140 ms; ping confirmado en 1 sondeo ⇒ **peor caso ≈ 0,3 s** con sondeo cada 200 ms (test `FastPathShowsANewPingWellUnderASecond`).
- **Limitación honesta**: sobre la captura de prueba (WebP reducido, cifras de 7 px) el OCR pierde el «1» fino y confunde 6/8: sale `6720`/`8,720`, y el decodificador lo lleva a `16,720` **marcándolo como corregido**. Con capturas nativas PNG (pendiente §6.2) debería leerlo directo. El icono se calibró con UNA captura real (naranja ≈ (210,120,50)) y otra de vídeo (amarillo ≈ (235,175,60)): **no verificado en juego con otras resoluciones/estados del marcador**.

### 12.2 Ramas
- `Overlay/Branches.cs` (Hauling, Minería; para añadir una: una entrada + etiquetar sus widgets en `WidgetCatalog`). Cada `WidgetDef` lleva su `Branch`; `OverlayWindow.ApplyBranch` oculta los demás (también en modo edición).
- `Pages/HomePage` (tarjetas) + selector «Rama activa» en la barra lateral + tecla `Hotkeys.SwitchBranch` (F5). `AppConfig.LastBranch` / `OpenInLastBranch` (Ajustes y pantalla de inicio).
- Procesos por rama (`OverlayController.Branches.cs`): al salir de Hauling se para el escaneo de contratos y sus teclas dejan de existir; en Hauling no hay vigilantes de minería; en Minería no hay escáner ni teclas de hauling. La disposición se guarda por widget (que es de una sola rama).
- Un botón de otra rama (p. ej. «Escanear misiones» estando en Minería) cambia de rama con aviso (`RequireBranch`).

### 12.3 La bodega no desaparece
- `MiningContent` (widget) pinta SIEMPRE la última lectura buena de bodega y roca con «Leído hace 12 s / 5 min / 1 h» (se actualiza cada segundo); se atenúa pasados `MiningHud.StaleAfterSec` (120 s) pero no se quita. Los pings quedan como «visto hace…» hasta `PingExpireMin` (10 min). `MiningLive.Clear()` solo se llama al **cambiar de rama**; al cerrar la app no hay nada persistido.

### 12.4 Cierre limpio
- **Causa** (confirmada con el log real: `Saliendo.` + `InvalidOperationException … ForceClose ← Quit ← OnClosing`): al cerrar la ventana principal, `OnClosing` llamaba a `Quit()` → `Close()` **dentro del propio evento de cierre**, que lanza; `Application.Shutdown()` no se alcanzaba y el overlay quedaba vivo. Además `Dispose` no paraba el vigilante lento ni liberaba el motor ONNX.
- **Ahora**: bandera `IsClosing` (cierre doble imposible), cierre diferido fuera del evento, `Quit` ordenado (guardar → watchdog → vigilantes con `Join` → ventanas → `Shutdown`), **salvaguarda**: a los 3 s `Process.Kill()` (los datos ya están guardados). Instancia única: la segunda trae al frente a la primera (`EventWaitHandle`) y termina; `--instance X` separa la instancia para pruebas.
- También corregido: `HotkeyManager.Poll` enumeraba la lista mientras una tecla la vaciaba/re-registraba (cambiar de rama o salir).
- **Medido**: cerrar la ventana principal y Ctrl+Alt+F12 terminan el proceso en 0,1–0,3 s, también con la rama Minería activa (ONNX en marcha); 0 procesos restantes.

### 12.5 Cómo probar cada punto en el juego
1. **Pings**: rama Minería → modo escaneo (V) → apunta a un campo. El ping debe aparecer en <1 s. Activa «Guardar diagnóstico» (Ajustes → Minería) y abre `debug-captures\mineria-pings\pings.log`: cada línea trae `ShownAfterMs`. Pasa el cursor/mira chat, distancias y «29.3K»: no debe salir ningún ping. Si algo sale «sin identificar», está en `Detail` con su encaje y en el recorte guardado.
2. **Ramas**: abre la app → pantalla de inicio. Entra en Minería: el overlay solo muestra el panel de minería; F3 oculta/muestra; F8/F9 no hacen nada. F5 → Hauling: solo misiones/ruta/etc. y el lector de minería para (Ajustes → Estado y diagnóstico lista las teclas registradas).
3. **Bodega**: en modo minería abre la lista de carga; pasa a modo escaneo (V): la bodega, el valor y «Leído hace…» siguen ahí y suben de segundos a minutos; tras 2 min se atenúan.
4. **Cierre**: cierra la ventana principal, y por otro lado Ctrl+Alt+F12, con el juego delante o no; en el Administrador de tareas no debe quedar «AXON CITIZEN».

### 12.6 Ajuste posterior: marcadores de otros colores
El detector de icono acepta ahora naranja/amarillo, azul/cian y verde (antes solo naranja), y el rango de valor ya no se acota por la firma mineral mas baja (minimo 1,000): un ping azul con 2,900 no se veia. Sin separador de miles, una cifra solo vale si una firma la explica. Captura de prueba: tests/samples/mining-hud/frames/pilot-scan-ping-blue.png (el numero a 1333 px comprimido no es legible por OCR; el icono si se localiza). **Sin verificar en juego con tu resolucion nativa.**

## 13. v13 — Fase 1 de minería: pings y tarjeta (qué cambió y cómo probarlo)

### 13.1 Diagnóstico (con los datos reales de `pings.log`, 11–12/10/2026, 5.152 líneas, 42 pings «confirmados»)
- **Tiempo en pantalla→mostrado**: el proceso en sí era rápido (`ShownAfterMs` media 412 ms, máx. 880 ms), pero **desde la primera vez que se veía el marcador hasta confirmarlo pasaban una media de 9,8 s y hasta 29,4 s**. Causas: (a) la huella del recuadro del número toleraba demasiado (`SameSig=10`): un número distinto en el mismo sitio se tomaba por «el mismo» y no se releía; (b) las lecturas viejas se quedaban en el acumulador y pesaban más que las nuevas; (c) los candidatos basura (3–7 iconos del HUD) hacían cada sondeo de 400–800 ms y retrasaban al ping real.
- **Falsos**: (1) **distancias con decimales** «90.8 m», «53.5 m», «106.2 m»… (el OCR solo-cifras quita la «m» y el decodificador quitaba el punto: salía 1908, 1535, 1062…); (2) **reparaciones inventadas**: «33,020»×6 → 33,920; «2,000»×6 → 12,000; «14,000»×6 → 19,000; «9,750» → 99,750; «1,520» → 11,520 (una «reparación» a un valor de firma válido, con 2 lecturas); (3) **otros**: «0.9750»/«0.66500» (potencia/porcentajes), «57M/S» (velocidad de un MFD: «27/0»), «4,245 m»-tipo (distancia en metros a un marcador).
- `debug-captures\dudosas` solo contiene 1 captura de **contratos** de hauling (09/10), no de pings; no hay falsos de ping ahí.

### 13.2 Qué se hizo
1. **Vigilancia del número en cada sondeo**: huella 12×4 con tolerancia 3 (antes 10); si el número cambia, se relee con otras variantes y se vacían las lecturas viejas; no depende de estabilidad global.
2. **Verificación por forma** (plantilla del pin sacada de la captura real a 3840×2160 y 2000×1125: cabeza hueca + base ancha, rejilla 10×12) y **por placa** (fondo teñido translúcido detrás del número; una etiqueta suelta va sobre el espacio) y por relación icono→número. Un «icono» dentro del recuadro del número de otro es un borde ClearType y se descarta.
3. **Estructura estricta del número**: solo `\d{1,2}[.,]\d{3}` o 4–5 cifras; los decimales no son miles. **Unidades**: 3 de las 7 lecturas son «normales» (conservan letras): «m», «km», «K», «%», «°», «/» vetan el marcador.
4. **Decodificador sin inventar**: si ≥2 lecturas coinciden (≥60 %), esa es la lectura; reparar (cifra confundida / «1» perdido) solo cuando las variantes discrepan y hay ≥3 válidas. «Sin identificar» si no encaja.
5. **Diagnóstico ampliado** (`pings.log`): `FirstSeen`, `FirstOcr`, `FirstSeenToShownMs`, `CaptureMs`, `DetectMs`, `OcrMs`, `DecideMs`, `IconColor`, `IconSize`, `Region` y recorte.

### 13.3 Mediciones (esta máquina; captura nativa 3840×2160 recortada a 1920×1080 + captura 2000×1125)
| | Antes (registro real) | Después (tests) |
|---|---|---|
| Ping nuevo: aparece → mostrado | media 9,8 s, máx. 29,4 s | 1 sondeo: **peor caso 276 ms**, media ≈ 265 ms (sondeo cada 200 ms) |
| Cambio de número en la zona: → mostrado | hasta 25 s (datos reales) | **peor caso 379 ms**, media 367 ms |
| Coste por sondeo (7 candidatos del HUD) | 400–800 ms de OCR cada vez | 1.º 400 ms, 2.º–3.º ≈ 70 ms, después **6–7 ms** (sin OCR) |
| Falsos en el registro real (38 de 42) | 38 | **0** (tests `RealFalsePingsFromTheLogAreNotPings`) |

### 13.4 Tarjeta del ping (widget `ping`, rama Minería)
`PING 16,720` → `HEPHAESTANITE (RAW) ×4` (alternativas debajo en pequeño, con encaje) → imagen → rareza → **precios por SCU** (bruto y refinado: media y máximo, dónde y fecha) → nota. El último ping se queda («visto hace…») y debajo hay un historial plegable con miniatura. Animación de entrada, sonido opcional, opacidad = la del overlay.
- **Precios** (`MineralPriceBook`): datos incluidos de UEX (sin terminal) + última copia de UEX con terminal y fecha (`%AppData%\AxonCitizen\data\mineral-prices.json`, se renueva cada 24 h en segundo plano). **Unidad: aUEC por SCU** (`price_sell` de `commodities_raw_prices_all` / `commodities_prices_all`; las cantidades de UEX van aparte en `scu_*`). No he podido leer la documentación de UEX desde aquí: la unidad se apoya en esa convención y en que la bodega valorada en el overlay (3,73 SCU de Tungsten ≈ 2.641 aUEC) es coherente.
- **Imágenes**: carpeta `%AppData%\AxonCitizen\images\minerals\` (manda tu `nombre.png`/`nombre.user.png`, después `nombre.capture.png`, después las descargadas). **No hay imágenes por mineral con licencia reutilizable** (la Wiki de SC usa un icono genérico de categoría; UEX no las expone/autoriza; el Fankit no trae iconos de minerales): el manifiesto `Data/mineral-images.json` está vacío y documenta la búsqueda; solo se descargan entradas con licencia permitida y https, guardando fuente y licencia. Sin imagen → icono ◆ con el color del mineral. «Usar mis capturas» (Ajustes → Minería) recorta el centro de tu pantalla al escanear una roca identificada.
- **Valor de las rocas**: depende de la masa de cada roca, que el ping no da: se muestra el valor por SCU y se avisa; no se inventa un total.

### 13.5 Cómo probarlo en el juego
1. Rama Minería → modo escaneo (V). Cada ping debe salir en <1 s con tarjeta; cambia de un ping a otro (incluso en la misma zona) y el nuevo sale en <1 s.
2. Con «Guardar diagnóstico», `debug-captures\mineria-pings\pings.log`: cada línea tiene `FirstSeenToShownMs`, `IconColor`, `Region`. Mira distancias («90.8m»), % y MFDs: no debe salir ningún ping.
3. Ajustes → Minería: sonido, «Usar mis capturas», carpeta de imágenes, actualizar precios.

### 13.6 Ajuste posterior: pings que son suma de rocas (4.10.x)
Un ping «14,000» salía «sin identificar». No es múltiplo de ninguna firma de mineral, pero el escáner SUMA todo lo del cúmulo y existen los depósitos de mano (FPS = 3.000) y de ROC/vehículo terrestre (= 4.000) (fuente: starvein.app «Small deposit (FPS)» / «Large deposit (ROC)»; «8,000 = 2 ROC deposits»). `PingInterpreter.Mixtures` descompone el valor en dos tipos de roca (a×X + b×Y, ≤10 rocas, tabla de la comunidad + FPS + ROC) y la tarjeta los lista como «posible mezcla» (14,000 → 2× depósito ROC + 2× depósito FPS entre otras). Sigue sin inventarse un mineral. Los valores base de los asteroides de nave NO han cambiado en 4.10.x según los pings aprendidos del usuario (Quantainium 3.170, Taranite 7.108–7.111 ≈ 2×3.555): lo que falta por verificar con datos reales es qué es cada mezcla; escanear la roca justo después enseña el valor a la app (`mining.json → Pings`). Valores sin descomposición (p. ej. 2,000, por debajo de cualquier firma) siguen «sin identificar».

## 14. Fase 2 — paso 1 y 2: calculadora de rotura en solitario (v14)
- **Motor** (`Axon.Core/Mining/Breaker/RockBreaker.cs`, datos en `Data/mining-breaker.json`): potencia = maxPower×1,2×módulos; resistencia = Π cabezal×(1+Σ(módulo−1))×gadget (tope 99,99); necesaria = masa/(1−res)/5; rompe si Σpotencias ≥ necesaria. Reglas y datos de la calculadora comunitaria Rock Breaker v3.22.0 (docs/reference/rockbreaker-reference.md): **sin verificar en juego**; la potencia máxima de los cabezales difiere de la Wiki (0,7–17 %) y hay que calibrarla con medidas.
- **Plan por láser** (`Throttles`, `BreakerAdvisor.OneRegulates`): barra QUIETA (potencia justa), SUBIR (+15 %), BAJAR (−15 %), todos al mismo % respetando el mínimo de cada cabezal, o «uno regula y el resto al 100 %». Los ±15 % son un valor inicial a calibrar con el CHARGE LEVEL real.
- **Si no rompe**: prueba cada gadget (uno solo por roca) y los módulos activos encendidos y dice cuál lo arregla; si ninguno, lo dice.
- **Perfil → informe** (`BreakerAdvisor.Report`): usa el equipo de la página Minería (cabezales, módulos, gadget, `ActiveLasers` = los N más potentes). Se ve en el overlay (ROCA) y en «Probar una roca» (Minería → Equipo, con masa, resistencia e inestabilidad).
- Tests: 17 nuevos (`RockBreakerTests`, valores calculados a mano).
- Siguiente (paso 3): puestos por tripulante (cada uno con su láser) y sala compartida (ping, bodega, roca).

## 15. Fase 2 — paso 3: puestos por tripulante (v15)
- **Puestos** (`HeadSetup.Seat/Person`, `MiningProfile.AbsentSeats/GadgetsOwned`): cada cabezal tiene un nombre de puesto y una persona; varios cabezales con el MISMO puesto = esa persona puede cambiar entre ellos (p. ej. «Atrás»: Hofstede-S2 o Helix II). Se edita en Minería → Equipo (puesto, persona, «puesto ocupado hoy», gadgets que tenéis).
- **Planificador** (`CrewPlanner.Plan`): prueba todas las combinaciones de puestos presentes × láser elegido × gadget (uno solo) × módulos activos apagados/encendidos y elige la que rompe con MENOS puestos, sin gadget si se puede, sin módulos activos si se puede, con ≥10 % de margen y la potencia más baja; el resto de puestos «sin láser». Si hace falta gadget, el de más margen.
- **% por puesto**: el láser más débil regula la barra (quieta / sube +15 % / baja −15 %) y los demás van fijos al 100 %; si el que regula ya está en su mínimo, todos al mismo % respetando mínimos.
- **Salida** (overlay ROCA y «Probar una roca»): «Torreta central (Tú): Helix II · enciende Surge — regula: quieta 68 % · sube 78 % · baja 58 %», «Atrás (Compañero): Hofstede-S2 — fijo al 100 %», «Gadget: Sabir», «Sin láser: …», y alternativas. Sin solución: «NO ROMPE · faltan N W incluso con todos los puestos…».
- Tests: 7 nuevos (`CrewPlannerTests`). Siguiente (paso 4): sala por código para compartir pings, bodega, roca y el plan entre los dos PCs.


## 16. Fase 2 — paso 4: sala compartida (v16)
- **Núcleo** (`Axon.Core/Party/PartyCore.cs`): código de sala de 6 caracteres (sin 0/O/1/I) → PBKDF2 → clave AES-256-GCM + identificador público de la sala (el relé solo ve el identificador). Mensajes: `hello/bye` (miembros, puesto, latido 5 s, caducan a los 20 s), `ping`, `cargo`, `rock`, `profile`. Se ignoran los de otra sala, manipulados, propios o repetidos (Id).
- **Transportes**: `TcpHostTransport` (un jugador hace de relé en su PC; misma red / Tailscale / Hamachi / puerto abierto), `TcpClientTransport`, `WsRelayTransport` (WebSocket a un relé; `tools/relay/worker.js` = Worker de Cloudflare con Durable Object, **sin desplegar ni probar**: el cliente sí está probado contra un relé WebSocket local equivalente).
- **Qué se comparte**: solo números ya interpretados (valor del ping, líneas de bodega, masa/resistencia/inestabilidad/composición de la roca, equipo de minería). Nunca capturas.
- **En la app** (`OverlayController.Party.cs`, Ajustes → «Minería · sala compartida»): nombre, puesto, modo (relé / anfitrión / entrar), crear sala, entrar con código, salir, «Enviar mi equipo a la sala», lista de miembros y direcciones donde te encuentran (modo anfitrión).
  - Ping de un compañero → entra en la lista como «visto hace…» con `From`; si ya tienes ese valor, solo refresca. Suena si el sonido está activo.
  - Bodega de un compañero → se aplica igual que la propia (`CargoFrom`); no se reenvía.
  - Roca de un compañero → recalcula el reparto con el equipo de la sala (`RockFrom`); no aprende firmas ni guarda imágenes (eso es de tu pantalla). La roca propia solo se publica si cambia.
  - Equipo: el último que edita el suyo en Minería lo publica y pasa a ser el de todos (opción «Usar el equipo que edite cualquiera»); recalcula la roca actual.
  - Tu línea del reparto (por puesto o nombre) sale resaltada con ▶.
- Tests: 7 nuevos en `PartyTests` (cifrado, otra sala, manipulado, TCP con anfitrión + 2 invitados, salida de miembro, sala ajena invisible, WebSocket).
- Pendiente: probar de verdad entre dos PCs; despliegue del Worker; lazo cerrado con el nivel de CARGA y calibración de los factores con mediciones reales.

## 17. Fase 2 — paso 5: ajuste en vivo con la barra real (v17)
- **Lazo cerrado** (`Axon.Core/Mining/Breaker/ChargeLoop.cs`): pendiente de la barra (CHARGE LEVEL, puntos/s, mínimos cuadrados sobre ~4 s, ≥3 lecturas y ≥0,8 s) → corrección del puesto que regula respecto al % del plan: barra sube → «baja X N puntos, de 68 % a 64 %»; baja → sube (tope 100 %); |pendiente| < 1/s → «estable, mantén». Si ya está en su mínimo / al 100 %, lo dice y propone otra cosa. Tamaño del paso = 0,8 puntos de % por punto/s, entre 1 y 10: **heurística inicial sin calibrar**. No se conoce el % realmente puesto en el juego: la corrección es respecto al plan.
- **Overlay**: línea «↻ …» bajo el consejo de carga (se oculta si hay aviso de Stop/Warn de `ChargeGuide`, que manda).
- **Registro de calibración** (`BreakerCalibrationLog`): `data\calibracion-rotura.jsonl`, una línea cada ≥5 s con roca, nave, plan por puesto (láser, módulos, % de mantener), potencia total/necesaria, nivel de carga, pendiente y tendencia. Sirve para ajustar el factor de potencia por cabezal cuando haya varias medidas con la barra casi quieta (ajuste aún no implementado).
- Tests: 7 nuevos (`ChargeLoopTests`).
- Pendiente: usar el registro para ajustar el ×1,2 por cabezal y el ±15 %; medir en juego.

## 18. Fase 2 — paso 6: calibración de la potencia con resultados reales (v18)
- **Idea** (`Axon.Core/Mining/Breaker/PowerCalibration.cs`): el juego rompe si f × potencia_modelo ≥ necesaria. Cada «rompió» da una cota inferior de f (= necesaria/aplicada) y cada «no rompió» una superior. Sin datos contradictorios f = 1; si los hay, el valor más cercano a 1 que explica todas las medidas (limitado a ×0,5–×1,5); si las medidas se contradicen entre sí, punto medio y aviso.
- **Uso**: Minería → Equipo → «Calibrar la potencia…»: tras una roca con reparto rompible, pones el % de potencia que aplicaste (por defecto 100) y pulsas «Rompió» / «No rompió». Se guarda en `data\calibracion-potencia.json` (máx. 200) y el factor (`BreakerData.UserPowerScale`, global) se aplica a todo el cálculo y recalcula la roca actual. «Borrar medidas» vuelve al modelo (×1,00).
- **Límites**: un único factor para todos los cabezales (no distingue Helix de Hofstede); no corrige las resistencias de módulos/gadgets ni el ±15 % de subir/bajar; las medidas útiles son las rocas JUSTAS (con margen grande no aportan nada). Las medidas del registro de barra (`calibracion-rotura.jsonl`) aún no se usan.
- Tests: 7 nuevos (`PowerCalibrationTests`); las clases del calculador van en la colección xUnit «Breaker» (el factor es estático).

## 19. Fase 2 — paso 7: decidir gadget (v19)
- **`GadgetAdvisor.Evaluate`** (`Axon.Core/Mining/Breaker/GadgetAdvisor.cs`): con el equipo del reparto (o, si no hay reparto posible, el mejor láser de cada puesto con módulos activos encendidos) evalúa cada gadget que tengáis (`GadgetsOwned`; vacío = todos) y dice si arregla la roca, el margen y qué cambia en inestabilidad / ventana / tasa de carga respecto a no usar ninguno.
- **Titular**: «Sin gadget ya rompe… no hace falta ninguno» / «…solo compensa uno si te preocupa la inestabilidad: BoreMax…» / «Sin gadget NO rompe (faltan N W). Lo arreglan: Sabir…» / «ninguno lo arregla». Siempre con el aviso «un solo gadget por roca (con dos puede explotar)».
- **Dónde**: overlay (sección ROCA, «GADGET: …»; el detalle solo si no rompe sin gadget o el plan ya lo usa) y «Probar una roca» (Minería → Equipo).
- **Límites**: no hay precios ni usos de los gadgets en los datos, así que «compensa» se mide solo por rotura y por efectos; efectos sin verificar en juego (calculadora comunitaria).
- Tests: 3 nuevos (`GadgetAdvisorTests`).

## 20. Fase 2 — paso 8: prueba de la sala entre dos procesos reales (v20)
- **Gancho de prueba**: `AxonCitizen.exe --data <dir> --instance X --party-test host:CODE|join:IP:CODE [--party-name N] [--party-port P]` abre la rama Minería, entra en la sala y manda datos sintéticos por los mismos caminos que los reales (ping, roca el anfitrión; bodega y equipo el invitado); a los ~8 s anota en el registro `PARTYTEST state …`. Script: `tools/party-test.ps1 -Exe <ruta>` (arranca anfitrión e invitado con datos separados y vuelca los registros).
- **Resultado (v20, 127.0.0.1)**: ambos conectan; ven la lista de miembros con puesto; el anfitrión recibe `cargo` y `profile` del invitado (bodega 7,7/96 SCU y equipo aplicado: «ProfileFrom=Operador»); el invitado recibe `ping` (16720, From=Piloto) y `rock` (RockFrom=Piloto) y calcula el reparto con el equipo de la sala. Registro de la app: «Sala: recibido «tipo» de X».
- **Sigue sin probarse**: entre dos PCs distintos (red/firewall/Tailscale) y el relé de Cloudflare.

## 21. Fase 2 — paso 9: reconexión de la sala y guía de uso (v21)
- **Reconexión automática** (`OverlayController.Party.cs`, `PartyBeginReconnect`): si el invitado/relé informa «Desconectado…», reintenta cada 5 s hasta 24 veces con el mismo código mientras no salgas tú de la sala (`_partyWanted`); estado visible en Ajustes («Sin conexión · reconectando (n/24)…»). El anfitrión no reconecta (es el relé). Probado (`tools/party-reconnect.ps1`): se mata el anfitrión, se relanza 8 s después y el invitado vuelve solo y recibe de nuevo los datos.
- **Guía** `GUIA-SALA-Y-ROTURA.md` (en la raíz y en el zip de la app): equipo, sala, qué se ve, calibración y fallos típicos.
- Pendiente igual que antes: prueba entre dos PCs distintos y relé de Cloudflare; medidas reales para calibrar.

## 22. Fase 2 — paso 10: medidas de calibración compartidas en la sala (v22)
- Al anotar «Rompió / No rompió» la medida (`PowerObservation`: roca, potencia necesaria y aplicada según el modelo, resultado) se publica en la sala (`calib`); quien la recibe la añade a su `calibracion-potencia.json` (sin duplicar: misma hora, resultado y potencia necesaria), recalcula el factor y la roca actual, y avisa «X ha anotado una medida…». Los dos PCs convergen al mismo factor sin repetir pruebas (supone el mismo equipo/modelo en ambos).
- Probado en `--party-test`: el anfitrión envía una medida (necesaria 5.500 W, aplicada 5.000 W, rompió) y el invitado queda con factor ×1,11.
- Test: `SameMeasureFromTheRoomIsNotCountedTwice`.

## 23. Fase 2 — paso 11: endurecimiento de la sala (v23)
- **Repeticiones**: `PartySession.Fresh` descarta mensajes cuyo sello de hora difiere más de 10 min del reloj local (un relé o un tercero que reenvíe mensajes cifrados viejos ya no puede reaplicarlos tras caducar la caché de Ids). Si dos PCs tienen el reloj desfasado más de 10 min, la sala no funcionará: hay que sincronizar la hora de Windows.
- **Tamaños y valores**: la app ignora (y anota en el registro) mensajes con datos >100 kB, equipos con >12 cabezales/>6 módulos, pings fuera de 1–999.999, bodegas con >40 líneas o cantidades absurdas, rocas con >30 componentes o masa >10 M kg.
- Tests: 2 nuevos (`FreshnessRejectsOldAndFutureMessages`, `ReplayedOldMessageIsIgnored`).

## 24. Fase 2 — paso 12: sala simple, solo con el código (v24)
- **Petición del usuario**: sin IP, puerto ni nada; «crear sala» o «unirse» y que todo vaya dentro del código.
- **Cómo**: modo `auto` (por defecto): `PartyServers.Create(roomId)` → `MultiTransport` de 3 clientes `MqttWsTransport` (MQTT 3.1.1 mínimo por WebSocket seguro, QoS 0) contra servidores públicos (HiveMQ `broker.hivemq.com:8884`, EMQX `broker.emqx.io:8084`, Mosquitto `test.mosquitto.org:8081`); tema `axoncitizen/v1/<roomId>`. Publica y escucha en todos a la vez; los duplicados los quita la sesión por Id (ahora atómico, `TryAdd`). Cada cliente se reconecta solo cada 5 s; basta con que uno funcione. El cifrado AES-GCM por código es el mismo: los servidores solo ven texto ilegible.
- **UI** (Ajustes → sala): «Tu nombre», **Crear sala**, «Unirme» + código; en la sala, código grande con **Copiar código**, «Enviar mi equipo» y «Salir». El puesto sale solo del cabezal cuya «Persona» es tu nombre. Host/join por IP, servidor propio y puerto quedan en «Opciones avanzadas» (cerrado por defecto).
- **Probado**: 5 tests (`PartyMqttTests`, servidor MQTT local falso, duplicados por varios servidores, un servidor caído, ningún servidor, y servidores públicos reales); y dos procesos reales con `--party-test auto-a:CODE` / `auto-b:CODE` por internet (ping, roca, medida, bodega y equipo llegan).
- **Límites**: depende de que los servidores públicos sigan abiertos y gratuitos (por eso se usan tres); el identificador del tema se deriva del código con PBKDF2 (20 000 iteraciones): un código de 6 caracteres se podría atacar por fuerza bruta offline por quien capture el tráfico, aceptable para datos de minería. Hace falta internet en ambos PCs.

## 25. Fase 2 — paso 13: la sala siempre a la vista y reentrada automática (v25)
- **Reentrada**: `PartySettings.InRoom` (se activa al entrar, se desactiva solo con «Salir de la sala», no al cerrar la app). Al abrir la app, `PartyAutoRejoin` vuelve a entrar sola en `LastCode` a los ~2,5 s. Probado (`tools/party-rejoin.ps1`): se cierra y se reabre y vuelve a la misma sala sin tocar nada.
- **Visible**: overlay de minería («👥 Sala K7M-2QX · Piloto, Operador» bajo la cabecera) y página Minería (botón «👥 Sala» que lleva a Ajustes + estado).
- Scripts de prueba en `tools/`: `party-test.ps1` (host/join local), `party-auto.ps1` (por internet con solo el código), `party-reconnect.ps1`, `party-rejoin.ps1`.

## 26. Fase 2 — paso 14: la calculadora aprende de tu juego + autoactualización (v26)
### 26.1 Aprendizaje a partir de lo que ves (`Axon.Core/Mining/Breaker/BarLearner.cs`, `OverlayController.Learn.cs`)
- **Qué se anota**: «con ESTE láser a ESTE % la barra SUBE / BAJA / SE MANTIENE» (botones en Minería → Equipo → «Entrenar la calculadora con tu juego», o automático desde la barra de carga con «Aprender solo de la barra»), y también «Rompió / No rompió». Se supone el resto de láseres al 100 %.
- **Qué aprende**: una desigualdad por observación: Σ f_láser × potencia_modelo × % ≷ necesaria × (1 + c·inestabilidad). Ajusta (descenso de subgradiente con pérdida bisagra, regularizado hacia el modelo) un **factor de potencia por cabezal** (0,5–1,5) y una **pendiente de inestabilidad** c (−0,5–0,5, fuertemente retenida en 0). Con pocas observaciones solo se mueve lo mínimo para explicarlas; cuando el modelo ya las explica no cambia nada. El factor por cabezal manda sobre el global de «Rompió/No rompió».
- **Efecto**: `BreakerData.HeadFactors` / `InstabilityNeedSlope` entran en `RockBreaker.Evaluate` → el reparto y los % de quieta/sube/baja ya cuentan con lo aprendido. Se ve en el overlay («IA: Helix II ×0,95 (4)») y en la página.
- **Datos**: `data\aprendizaje-barra.json` (máx. 600; no repite la misma observación en 20 s). «Borrar aprendizaje» vuelve al modelo.
- **Autoprueba**: `--learn-test`; con una observación que contradice al modelo el % propuesto pasó de 86 % a 91 % y el factor del láser a ×0,95.
- **Límites**: la barra solo dice sube/baja/estable (no cuánto), así que hacen falta varias observaciones a % distintos; el aprendizaje automático supone que el % que escribes es el real; no es una red neuronal (con tan pocos datos sería peor): es un ajuste explicable de los parámetros del modelo físico.
### 26.2 Autoactualización (`Axon.Core/Update/AppUpdater.cs`, `OverlayController.Update.cs`)
- **Versión**: `AppVersion.Build` (26). Súbela en cada entrega.
- **Publicar una versión**: `python tools/make-update.py <build> <carpeta publicada> <salida> "<novedades>"` genera `AXON-CITIZEN-update-vN.zip` (sin `models`) y `latest.json` (`build`, `version`, `file`, `sha256`, `size`, `notes`); se suben a cualquier alojamiento https (p. ej. GitHub Releases: `https://github.com/<usuario>/<repo>/releases/latest/download/latest.json`).
- **En la app** (Ajustes → Actualizaciones): dirección del `latest.json`, buscar sola (25 s tras abrir y cada 6 h), instalar al cerrar, «Buscar ahora», «Reiniciar y actualizar». Descarga → comprueba SHA-256 → descomprime (anti zip-slip) en `<datos>\update\stage-N`.
- **Instalación**: script PowerShell desligado: espera al proceso, copia de seguridad (`update\backup`, sin `models`), `robocopy /E /IS /IT` sobre la carpeta de la app, vuelta atrás si falla (código ≥ 8), reabre (solo con «Reiniciar»). Los datos del usuario (%APPDATA%\AxonCitizen) no se tocan. Una compilación de desarrollo (`\bin\`) no se actualiza.
- **Probado**: 6 tests + extremo a extremo con la app real (v26 detecta v27 en un servidor local, descarga, verifica, y al cerrar instala el fichero nuevo; log `apply-update.log`).
- **Pendiente**: elegir dónde alojar `latest.json` y el zip (sin eso la app no tiene de dónde actualizarse).

## 27. Fase 2 — paso 15: entrenar sin salir del juego (v27)
- **Atajos** (`MiningHudSettings.Learn*Key`, solo en la rama Minería): `Ctrl+Alt+PageUp` = la barra SUBE con mi %, `Ctrl+Alt+End` = se MANTIENE, `Ctrl+Alt+PageDown` = BAJA, `Ctrl+Alt+Up/Down` = mi % ±1, `Ctrl+Alt+Right` = otro láser del reparto. Cada anotación suena y el overlay muestra «🎓 Hofstede-S2 al 20 %: SUBE ▲ anotado». Si no has elegido láser empieza por el primero del reparto con su % propuesto.
- **Deshacer la última** (botón) por si te equivocas de tecla (`BarLearner.UndoLast`).
- La página de Minería sigue lo que cambias con las teclas (láser y %).
- **Probado** con el juego simulado y pulsaciones reales (`--learn-keys-test` + `learn-keys.ps1`): los 6 atajos se detectan y anotan; con datos contradictorios el ajuste lo refleja («33 % explicadas»).
- Número de versión: `AppVersion.Build = 27`.

## 28. Fase 2 — paso 16: % por puesto en el entrenamiento (v28)
- **Problema**: el entrenamiento suponía que solo UN láser se tocaba y el resto estaba al 100 %, y los % se asociaban al nombre del cabezal (dos Helix iguales en puestos distintos se confundían).
- **Ahora**: cada **puesto** del reparto conserva su propio % (los no tocados valen 100). Con «otro láser» (`Ctrl+Alt+→` o el desplegable) cambias de puesto y vuelves a él con el % que dejaste; cada anotación (tecla, botón o barra automática) guarda el % de TODOS los puestos. El overlay muestra «🎓 ▶ Torreta central 68 % · Atrás 100 %».
- `BarLearner.Observe` indexa por puesto (`SeatAssignment.Seat`), no por cabezal.
- Test nuevo: dos Helix II en dos puestos no se mezclan. Simulación `--learn-keys-sim`: otro-láser → 86 %, +3 → 89 %, sube/baja/mantiene anotados.
- Número de versión: `AppVersion.Build = 28`.

## 29. Fase 2 — paso 17: lectura automática del nivel de carga y del % del láser (v29)
- **Hallazgo**: en modo automático el nivel de carga («0 - EMPTY») **no se leía** (solo lo hacía el modo de zonas fijas), así que la línea ↻ del lazo cerrado y el aprendizaje automático no recibían datos. Corregido.
- **Además**: el HUD muestra el **% de intensidad del láser** («100 % LASER INTENSITY», a la derecha del arco). Se lee y se usa como el % real del puesto de este jugador: ya no hay que teclearlo.
- **Cómo** (`ChargeReader`, `ChargeWatcher`): a partir de las anclas CHARGE LEVEL y LASER RANGE que halla el lector lento, calcula dos cajas a distancias proporcionales a su separación (sirve en cualquier resolución), las recorta ajustadas al texto (franja de filas con más píxeles de texto + grupo de columnas; las estrellas y el chat blanco no cuentan) y las lee con el reconocedor rápido cada `ChargePollMs` (300 ms) solo en modo minería.
- **Aprendizaje**: el % leído fija el de tu puesto (`MyLearnSeat`: el de la sala según «Persona», o el elegido, o el primero); cada jugador publica el suyo (`intensity`) y los demás puestos del reparto usan el % real de sus compañeros → observaciones con todos los % reales, sin teclear nada. «Aprender solo de la barra» sigue siendo opcional.
- **Overlay**: «⚡ Láser al N %» junto al consejo de carga.
- **Pruebas**: `ChargeReaderTests` sobre captura real (`cockpit-fracture-empty.png`): carga 0/EMPTY, láser 100 %. Simulación `--learn-auto-sim`.
- **Sin verificar**: solo hay una captura real con este indicador (rojo «EMPTY», 100 %). Otros estados (verde/«OPTIMAL», otros %, otras resoluciones o FOV) pueden necesitar ajustes de las cajas o del color: si algo no se lee, envía una captura con el indicador visible.

## 30. Fase 2 — paso 18: la lectura de carga no se inventa nada (v30)
- Al probar `ChargeReader` con el resto de capturas reales apareció un **falso positivo**: en `pilot-mining-cargo.png` leía «5 - TENORE» de las etiquetas flotantes «TUNGSTEN (ORE)» que rodean al arco. Ahora el texto debe tener exactamente la forma «N - PALABRA» (y número y palabra a la vez); lo demás se ignora.
- Tests nuevos (`FramesWithoutTheChargeIndicatorGiveNoReading`): `pilot-mining-cargo`, `rock-scan`, `pilot-scan-ping` (y variantes azul/naranja nativo) y `ping-video-frame` no dan ni nivel de carga ni % de láser. `cockpit-fracture-empty` sigue dando 0/EMPTY y 100 %.
- `AppVersion.Build = 30`.

## 31. Robustez de la lectura de carga a otras resoluciones (v31)
- Prueba con la captura real reescalada a 1280, 1600, 1920, 2560 y 3840 px de ancho (`ReadsTheSameFrameAtOtherResolutions`): carga 0/EMPTY y láser 100 % en todas. A 1600 el OCR perdía una letra («EMPY»): ahora la palabra se ajusta a las conocidas por distancia de edición (`ChargeReader.SnapWord`, ≥ 0,75; lista `KnownWords`); una palabra desconocida se conserva tal cual si es lo único que sale.
- `AppVersion.Build = 31`.
